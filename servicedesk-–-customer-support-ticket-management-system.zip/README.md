# ServiceDesk – Customer Support Ticket Management System

> **A Salesforce CRM Portfolio Project for Freshers & Administrators**  
> Demonstrating production-grade CRM concepts: Custom Objects, Relationships, Case Management, Automated Routing, Validation Rules, SLAs, Reports, Dashboards, and Role-Based Access Control (RBAC).

---

## 1. Project Overview

**ServiceDesk** is a responsive customer support CRM web application modeled directly on **Salesforce Service Cloud**. It equips a customer support organization to register customer accounts, manage support agent service resources, triage and resolve customer inquiries through standardized lifecycle workflows, automate case assignments with Omni-Channel workload balancing, and track real-time SLA deadlines.

The application includes an **AI Ticket Assistant** powered by Google Gemini 3.8 Flash to analyze ticket logs, identify root causes, recommend categories/priorities, and draft professional customer replies.

---

## 2. Salesforce CRM Architecture Mapping

This project was intentionally engineered to reflect real-world Salesforce configuration and development standards:

| Application Feature | Salesforce Service Cloud Standard / Concept | Architecture Details |
| :--- | :--- | :--- |
| **Customer Entity** | `Account` & `Contact` Standard Objects | Stores business account coordinates, industry, email, phone, and lifecycle status (`Active` / `Inactive`). |
| **Ticket Entity** | `Case` Standard Object | Primary transactional entity containing Subject, Description, Category picklist, Priority, Status Path, and SLA dates. |
| **Support Agent Entity**| `User` & `ServiceResource` (Omni-Channel)| Personnel records with Department categorization, certified skills tags, and live capacity/workload limits. |
| **Relationships** | Lookup & Master-Detail Relationships | Ticket contains Lookup relationship to Customer (Account) and Assigned Agent (Owner/User). |
| **Automated Routing** | **Case Assignment Rules** & **Salesforce Flow** | Automatic rule-engine that matches category skills and routes to the available agent with the lowest active workload. |
| **Lifecycle Workflow** | **Support Process** & **Path** | Visual Chevron workflow guiding tickets through `New` → `Open` → `In Progress` → `Waiting for Customer` → `Resolved` → `Closed`. |
| **Validation Rules** | **Salesforce Validation Rules** | Prohibits blank subjects, invalid emails, empty resolution notes on `Resolved` status, and prevents deleting accounts/agents with active tickets. |
| **SLA Tracking** | **Entitlement Management** & **Milestones** | Dynamic deadline math: Critical (4h), High (8h), Medium (24h), Low (48h) with real-time countdowns and overdue state calculation. |
| **Reporting Engine** | **Salesforce Reports & Dashboards** | Live operational metrics, SLA compliance rate, MTTR calculations, Agent Performance Matrix, and CSV export. |
| **Security & Access** | **Profiles, Roles & Permission Sets** | Interactive profile switcher simulating `Admin`, `Support Manager`, and `Support Agent` permissions. |
| **AI Assistant** | **Salesforce Einstein Service AI** | Server-side Gemini API integration for issue triage, root-cause identification, and automated response drafting. |

---

## 3. Key Features

- **Operational Operations Dashboard**:
  - 8 real-time KPI cards: Total Tickets, Open Tickets, In Progress, Resolved, Closed, Critical Tickets, Overdue Tickets, and Available Agents.
  - Interactive charts for Status, Priority, Category taxonomy, and Agent Capacity.
  - Urgent Attention Queue highlighting critical and overdue cases.
- **Support Ticket Management (Cases)**:
  - Table and card views with live multi-field global search and filter combinations.
  - Interactive Salesforce Path for visual status transitions.
  - Field audit history tracking (old value, new value, timestamp, modifier).
  - Chronological comment feed with support for private internal notes.
- **Customer Directory (Accounts & Contacts)**:
  - Full CRUD operations with email validation.
  - Related List view displaying all cases linked to an account via lookup reference.
  - Deletion lock preventing account deletion if active cases exist.
- **Support Agent Directory (Service Resources)**:
  - Skill tagging (e.g., Technical Issue, Billing, Login, API).
  - Availability status management (`Available`, `Busy`, `Offline`).
  - Active ticket workload counter automatically reconciled against case status changes.
- **Automated Case Assignment Rules**:
  - Matches ticket taxonomy with agent skills.
  - Dynamically evaluates agent availability and assigns to the agent with the lowest active workload.
- **Automated Test Suite Runner**:
  - 18 built-in automated test cases that execute in the browser with pass/fail telemetry.
  - Covers validations, SLA math, assignment rules, workflow transitions, and referential integrity constraints.

---

## 4. Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Lucide Icons
- **Backend**: Node.js, Express, tsx
- **AI Integration**: Google GenAI SDK (`@google/genai`), Gemini 3.8 Flash model
- **Persistence**: Unified `localStorage` storage service with automated schema seeding and JSON export/backup
- **Build System**: Vite, esbuild

---

## 5. Getting Started & Running Locally

### Prerequisites
- Node.js 18+ and npm installed.

### Installation
```bash
# Clone the repository and install dependencies
npm install

# Set up environment variables (optional for local mock fallback)
cp .env.example .env
# Add your GEMINI_API_KEY if desired for live AI completions:
# GEMINI_API_KEY=your_key_here
```

### Running Development Server
```bash
npm run dev
```
The server will start on port `3000` (http://localhost:3000).

### Production Build
```bash
npm run build
npm start
```

---

## 6. Built-in Automated Test Suite (18 Scenarios)

The application includes an in-app interactive test runner under **Settings & Testing**:

1. **Customer Creation Validation**: Confirms valid name and email schemas.
2. **Duplicate Email Validation Rule**: Verifies account email uniqueness.
3. **Support Agent Record Integrity**: Confirms presence of skills and department.
4. **Ticket Lookup Integrity**: Verifies every case references a valid customer account.
5. **Required Field Validation Rule**: Validates mandatory fields on case creation.
6. **SLA Calculation (Critical - 4h)**: Asserts accurate target deadline math.
7. **SLA Calculation (High - 8h)**: Asserts accurate target deadline math.
8. **SLA Calculation (Medium - 24h)**: Asserts accurate target deadline math.
9. **SLA Calculation (Low - 48h)**: Asserts accurate target deadline math.
10. **Automated Assignment Routing**: Verifies category skill matching to available agents.
11. **Workload Balancing Logic**: Verifies cases route to the least busy agent.
12. **Status Workflow Validation**: Enforces prohibited vs. allowed transitions.
13. **Mandatory Resolution Notes Rule**: Requires notes before moving to `Resolved`.
14. **Ticket Reopen Lifecycle Rule**: Validates cases can only reopen from `Resolved` or `Closed`.
15. **Overdue SLA Calculation Accuracy**: Verifies expired cases trigger overdue state.
16. **Customer Deletion Restriction**: Blocks deleting accounts with active cases.
17. **Agent Deletion Restriction**: Blocks deleting agents with active assigned workload.
18. **Category Deletion Restriction**: Blocks deleting categories linked to existing cases.
