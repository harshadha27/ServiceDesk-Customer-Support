import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API Health
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "ServiceDesk CRM API",
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// Heuristic fallback generator when Gemini API is unavailable or rate-limited
function generateHeuristicAnalysis(subject = "", description = "", customerName = "Valued Customer") {
  const text = `${subject} ${description}`.toLowerCase();
  
  let suggestedCategory = "Technical Issue";
  let suggestedPriority = "Medium";
  let priorityRationale = "Standard business operational ticket requiring timely investigation.";
  let keyIssue = "System functionality or operational assistance requested.";

  if (text.includes("urgent") || text.includes("outage") || text.includes("crash") || text.includes("down") || text.includes("breach") || text.includes("emergency") || text.includes("data loss")) {
    suggestedPriority = "Critical";
    priorityRationale = "High business impact keywords detected indicating severe operational impediment.";
  } else if (text.includes("error") || text.includes("cannot access") || text.includes("failed") || text.includes("blocked") || text.includes("deadline")) {
    suggestedPriority = "High";
    priorityRationale = "User workflow blocked; expedited resolution recommended within SLA guidelines.";
  } else if (text.includes("how to") || text.includes("question") || text.includes("minor") || text.includes("suggestion")) {
    suggestedPriority = "Low";
    priorityRationale = "Informational or non-blocking inquiry, eligible for standard queue priority.";
  }

  if (text.includes("invoice") || text.includes("charge") || text.includes("payment") || text.includes("refund") || text.includes("bill") || text.includes("subscription")) {
    suggestedCategory = "Billing";
    keyIssue = "Discrepancy or inquiry regarding payment, subscription, or billing statement.";
  } else if (text.includes("password") || text.includes("login") || text.includes("mfa") || text.includes("authenticate") || text.includes("sign in") || text.includes("locked")) {
    suggestedCategory = "Login";
    keyIssue = "User authentication failure or credential lock preventing portal access.";
  } else if (text.includes("feature") || text.includes("would like") || text.includes("enhancement") || text.includes("add support")) {
    suggestedCategory = "Feature Request";
    keyIssue = "Product enhancement proposal or user workflow enhancement request.";
  } else if (text.includes("account") || text.includes("profile") || text.includes("permission") || text.includes("role") || text.includes("invite")) {
    suggestedCategory = "Account";
    keyIssue = "User authorization, tenant profile or organizational permission modification.";
  } else if (text.includes("bug") || text.includes("api") || text.includes("sync") || text.includes("integration") || text.includes("exception")) {
    suggestedCategory = "Technical Issue";
    keyIssue = "Application technical malfunction or unexpected runtime behavior.";
  }

  const issueSummary = subject
    ? `${subject.trim()}. ${description.slice(0, 140).trim()}${description.length > 140 ? "..." : ""}`
    : `Customer experiencing issue regarding ${keyIssue.toLowerCase()}`;

  const suggestedResponse = `Hi ${customerName},\n\nThank you for reaching out to ServiceDesk Support regarding your inquiry on "${subject || keyIssue}".\n\nWe have logged your ticket and our engineering team is actively reviewing your case details. We are investigating the reported behavior and will provide our next status update shortly.\n\nBest regards,\nServiceDesk Tier 2 Support Team`;

  return {
    issueSummary,
    suggestedCategory,
    suggestedPriority,
    priorityRationale,
    suggestedResponse,
    keyIssue,
    suggestedAction: "Verify reproduction steps in staging environment and confirm tenant authorization state.",
  };
}

// AI Ticket Assistant Endpoint
app.post("/api/ai/ticket-assistant", async (req, res) => {
  try {
    const { subject = "", description = "", customerName = "Valued Customer", currentCategory = "", currentPriority = "" } = req.body;

    if (!description && !subject) {
      return res.status(400).json({ error: "Ticket subject or description is required." });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              "User-Agent": "aistudio-build",
            },
          },
        });

        const prompt = `You are an expert enterprise CRM Support Assistant for "ServiceDesk".
Analyze this support ticket record and generate concise, structured suggestions for the support agent:

Customer Name: ${customerName}
Ticket Subject: ${subject || "N/A"}
Current Category: ${currentCategory || "N/A"}
Current Priority: ${currentPriority || "N/A"}

Ticket Description:
${description}

Generate realistic, professional CRM recommendations strictly in JSON adhering to this schema:
{
  "issueSummary": "Concise 1-2 sentence overview of the user's issue",
  "suggestedCategory": "Must be one of: Technical Issue | Billing | Account | Login | Product | Feature Request | Other",
  "suggestedPriority": "Must be one of: Low | Medium | High | Critical",
  "priorityRationale": "Clear rationale for SLA urgency based on business impact",
  "suggestedResponse": "A polished, warm, professional email response ready to send to the customer",
  "keyIssue": "The underlying technical or business friction point",
  "suggestedAction": "Next concrete action the agent should execute"
}`;

        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                issueSummary: { type: Type.STRING },
                suggestedCategory: { type: Type.STRING },
                suggestedPriority: { type: Type.STRING },
                priorityRationale: { type: Type.STRING },
                suggestedResponse: { type: Type.STRING },
                keyIssue: { type: Type.STRING },
                suggestedAction: { type: Type.STRING },
              },
              required: [
                "issueSummary",
                "suggestedCategory",
                "suggestedPriority",
                "priorityRationale",
                "suggestedResponse",
                "keyIssue",
                "suggestedAction",
              ],
            },
          },
        });

        const textOutput = response.text;
        if (textOutput) {
          const parsed = JSON.parse(textOutput);
          return res.json({
            success: true,
            aiGenerated: true,
            source: "gemini-3.8-flash",
            data: parsed,
          });
        }
      } catch (geminiError: any) {
        console.warn("Gemini API call failed, falling back to heuristic engine:", geminiError?.message);
      }
    }

    // Fallback to local heuristic engine
    const heuristicData = generateHeuristicAnalysis(subject, description, customerName);
    return res.json({
      success: true,
      aiGenerated: true,
      source: "rule-based-assistant",
      data: heuristicData,
    });
  } catch (error: any) {
    console.error("Error in /api/ai/ticket-assistant:", error);
    return res.status(500).json({
      error: "Failed to generate AI recommendations",
      message: error?.message || "Unknown error",
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ServiceDesk Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
