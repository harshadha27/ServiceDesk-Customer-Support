import React, { useState, useEffect, useMemo } from 'react';
import {
  Customer,
  Agent,
  Ticket,
  TicketCategory,
  TicketComment,
  TicketHistoryItem,
  UserRole,
  TicketPriority,
  TicketStatus,
} from './types';
import { storageService } from './services/storageService';
import { calculateSlaStatus } from './services/automationService';
import { Sidebar, ActiveModule } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { Dashboard } from './components/dashboard/Dashboard';
import { TicketList } from './components/tickets/TicketList';
import { TicketDetails } from './components/tickets/TicketDetails';
import { TicketCreateModal } from './components/tickets/TicketCreateModal';
import { CustomerList } from './components/customers/CustomerList';
import { AgentList } from './components/agents/AgentList';
import { CategoryList } from './components/categories/CategoryList';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { SalesforceConceptsModal } from './components/common/SalesforceConceptsModal';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export default function App() {
  // Application Data State from localStorage
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [categories, setCategories] = useState<TicketCategory[]>([]);
  const [comments, setComments] = useState<TicketComment[]>([]);
  const [history, setHistory] = useState<TicketHistoryItem[]>([]);

  // Navigation & View State
  const [currentModule, setCurrentModule] = useState<ActiveModule>('dashboard');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

  // Global search & ticket filtering
  const [searchQuery, setSearchQuery] = useState('');
  const [ticketFilters, setTicketFilters] = useState<{
    status?: string;
    priority?: string;
    overdueOnly?: boolean;
    search?: string;
  }>({});

  // Role-Based Access Control State
  const [activeRole, setActiveRole] = useState<UserRole>('Admin');

  // Modals
  const [createTicketOpen, setCreateTicketOpen] = useState(false);
  const [conceptsOpen, setConceptsOpen] = useState(false);

  // Toast Notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4000);
  };

  // Initial Load from Storage
  const refreshData = () => {
    setCustomers(storageService.getCustomers());
    setAgents(storageService.getAgents());
    setTickets(storageService.getTickets());
    setCategories(storageService.getCategories());
    setComments(storageService.getComments());
    setHistory(storageService.getHistory());
  };

  useEffect(() => {
    refreshData();
  }, []);

  // Quick stats for badges
  const openTicketsCount = useMemo(() => {
    return tickets.filter((t) => t.status !== 'Closed' && t.status !== 'Resolved').length;
  }, [tickets]);

  const criticalTicketsCount = useMemo(() => {
    return tickets.filter((t) => t.priority === 'Critical' && t.status !== 'Closed' && t.status !== 'Resolved').length;
  }, [tickets]);

  // Selected Ticket Object
  const selectedTicket = useMemo(() => {
    if (!selectedTicketId) return null;
    return tickets.find((t) => t.id === selectedTicketId) || null;
  }, [tickets, selectedTicketId]);

  const selectedTicketComments = useMemo(() => {
    if (!selectedTicketId) return [];
    return comments.filter((c) => c.ticketId === selectedTicketId);
  }, [comments, selectedTicketId]);

  const selectedTicketHistory = useMemo(() => {
    if (!selectedTicketId) return [];
    return history.filter((h) => h.ticketId === selectedTicketId);
  }, [history, selectedTicketId]);

  // Handlers for Ticket Operations
  const handleCreateTicket = (payload: {
    subject: string;
    description: string;
    customerId: string;
    category: string;
    priority: TicketPriority;
    assignedAgentId?: string | null;
  }) => {
    try {
      const res = storageService.createTicket(payload);
      if (res.success && res.ticket) {
        refreshData();
        const assignmentMessage = res.ticket.assignedAgentName
          ? `Auto-assigned to ${res.ticket.assignedAgentName} via Omni-Channel rule.`
          : 'Routed to Queue.';
        showToast(`Ticket ${res.ticket.id} created! ${assignmentMessage}`, 'success');
        return { success: true };
      } else {
        return { success: false, error: res.error || 'Failed to create ticket.' };
      }
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const handleUpdateStatus = (ticketId: string, status: TicketStatus, notes?: string) => {
    const author = activeRole === 'Admin' ? 'System Administrator' : activeRole === 'Support Manager' ? 'Support Manager' : 'Support Agent';
    const res = storageService.updateTicketStatus(ticketId, status, author, notes);
    if (res.success) {
      refreshData();
      showToast(`Ticket status updated to "${status}".`, 'success');
    }
    return res;
  };

  const handleUpdatePriority = (ticketId: string, priority: TicketPriority) => {
    const author = activeRole === 'Admin' ? 'System Administrator' : activeRole === 'Support Manager' ? 'Support Manager' : 'Support Agent';
    const res = storageService.updateTicketPriority(ticketId, priority, author);
    if (res.success) {
      refreshData();
      showToast(`Priority updated to "${priority}". SLA recalculated.`, 'success');
    }
    return res;
  };

  const handleReassignAgent = (ticketId: string, agentId: string | null) => {
    const author = activeRole === 'Admin' ? 'System Administrator' : activeRole === 'Support Manager' ? 'Support Manager' : 'Support Agent';
    const res = storageService.reassignTicketAgent(ticketId, agentId, author);
    if (res.success) {
      refreshData();
      const agent = agents.find((a) => a.id === agentId);
      showToast(`Ticket reassigned to ${agent ? agent.fullName : 'Unassigned Queue'}.`, 'success');
    }
    return res;
  };

  const handleAddComment = (ticketId: string, comment: string, isInternal: boolean) => {
    const author = activeRole === 'Admin' ? 'System Administrator' : activeRole === 'Support Manager' ? 'Support Manager' : 'Support Agent';
    try {
      storageService.addComment({
        ticketId,
        author,
        comment,
        isInternal,
      });
      refreshData();
      showToast(isInternal ? 'Internal note logged.' : 'Customer response posted.', 'success');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  // Handlers for Customers
  const handleCreateCustomer = (data: Omit<Customer, 'id' | 'createdDate'>) => {
    const res = storageService.createCustomer(data);
    if (res.success) {
      refreshData();
      showToast(`Customer account "${data.fullName}" created.`, 'success');
    }
    return res;
  };

  const handleUpdateCustomer = (id: string, updates: Partial<Customer>) => {
    const res = storageService.updateCustomer(id, updates);
    if (res.success) {
      refreshData();
      showToast('Customer account updated.', 'success');
    }
    return res;
  };

  const handleDeleteCustomer = (id: string) => {
    const res = storageService.deleteCustomer(id);
    if (res.success) {
      refreshData();
      showToast('Customer account removed.', 'success');
    }
    return res;
  };

  // Handlers for Agents
  const handleCreateAgent = (data: Omit<Agent, 'id' | 'activeTickets'>) => {
    const res = storageService.createAgent(data);
    if (res.success) {
      refreshData();
      showToast(`Support Agent "${data.fullName}" created.`, 'success');
    }
    return res;
  };

  const handleUpdateAgent = (id: string, updates: Partial<Agent>) => {
    const res = storageService.updateAgent(id, updates);
    if (res.success) {
      refreshData();
      showToast('Support Agent record updated.', 'success');
    }
    return res;
  };

  const handleDeleteAgent = (id: string) => {
    const res = storageService.deleteAgent(id);
    if (res.success) {
      refreshData();
      showToast('Support Agent deleted.', 'success');
    }
    return res;
  };

  // Handlers for Categories
  const handleCreateCategory = (cat: { name: string; description: string }) => {
    const res = storageService.createCategory(cat);
    if (res.success) {
      refreshData();
      showToast(`Category taxonomy "${cat.name}" created.`, 'success');
    }
    return res;
  };

  const handleUpdateCategory = (id: string, updates: Partial<TicketCategory>) => {
    const res = storageService.updateCategory(id, updates);
    if (res.success) {
      refreshData();
      showToast('Category taxonomy updated.', 'success');
    }
    return res;
  };

  const handleDeleteCategory = (id: string) => {
    const res = storageService.deleteCategory(id);
    if (res.success) {
      refreshData();
      showToast('Category deleted.', 'success');
    }
    return res;
  };

  // Reset Sample Data
  const handleResetData = () => {
    storageService.resetToDefaults();
    refreshData();
    setSelectedTicketId(null);
    setCurrentModule('dashboard');
    showToast('Database reset to default 10 Customers, 5 Agents, and 20 Tickets.', 'info');
  };

  // Export JSON
  const handleExportJson = () => {
    const dump = storageService.exportAllData();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(dump);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ServiceDesk_Backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Full database JSON backup downloaded.', 'success');
  };

  // Navigate to Tickets with pre-set filters from Dashboard
  const handleNavigateWithFilter = (filter: { status?: string; priority?: string; overdueOnly?: boolean }) => {
    setSelectedTicketId(null);
    setTicketFilters(filter);
    setCurrentModule('tickets');
  };

  // Handle Global Search from Header
  const handleGlobalSearchChange = (val: string) => {
    setSearchQuery(val);
    if (val.trim() && currentModule !== 'tickets') {
      setSelectedTicketId(null);
      setCurrentModule('tickets');
    }
    setTicketFilters((prev) => ({ ...prev, search: val }));
  };

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden font-sans antialiased text-slate-900">
      {/* Sidebar Navigation */}
      <Sidebar
        currentModule={currentModule}
        onNavigate={(mod) => {
          setSelectedTicketId(null);
          setCurrentModule(mod);
        }}
        openTicketsCount={openTicketsCount}
        criticalTicketsCount={criticalTicketsCount}
        activeRole={activeRole}
        onOpenConcepts={() => setConceptsOpen(true)}
        onResetData={handleResetData}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header
          searchQuery={searchQuery}
          onSearchChange={handleGlobalSearchChange}
          activeRole={activeRole}
          onRoleChange={(r) => {
            setActiveRole(r);
            showToast(`Switched active profile to ${r}.`, 'info');
          }}
          onOpenCreateTicket={() => setCreateTicketOpen(true)}
          onOpenConcepts={() => setConceptsOpen(true)}
          criticalAlertCount={criticalTicketsCount}
        />

        {/* Scrollable View Container */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {/* If a Ticket is selected, show TicketDetails */}
            {selectedTicket ? (
              <TicketDetails
                ticket={selectedTicket}
                agents={agents}
                customers={customers}
                categories={categories}
                comments={selectedTicketComments}
                history={selectedTicketHistory}
                activeRole={activeRole}
                onBack={() => setSelectedTicketId(null)}
                onNavigateToCustomer={(custId) => {
                  setSelectedTicketId(null);
                  setCurrentModule('customers');
                }}
                onNavigateToAgent={(agentId) => {
                  setSelectedTicketId(null);
                  setCurrentModule('agents');
                }}
                onUpdateStatus={handleUpdateStatus}
                onUpdatePriority={handleUpdatePriority}
                onReassignAgent={handleReassignAgent}
                onAddComment={handleAddComment}
              />
            ) : (
              <>
                {/* Module: Dashboard */}
                {currentModule === 'dashboard' && (
                  <Dashboard
                    tickets={tickets}
                    agents={agents}
                    customers={customers}
                    onSelectTicket={(id) => setSelectedTicketId(id)}
                    onNavigateToTicketsWithFilter={handleNavigateWithFilter}
                  />
                )}

                {/* Module: Tickets List */}
                {currentModule === 'tickets' && (
                  <TicketList
                    tickets={tickets}
                    agents={agents}
                    customers={customers}
                    categories={categories}
                    onSelectTicket={(id) => setSelectedTicketId(id)}
                    onOpenCreateModal={() => setCreateTicketOpen(true)}
                    initialFilters={ticketFilters}
                  />
                )}

                {/* Module: Customers */}
                {currentModule === 'customers' && (
                  <CustomerList
                    customers={customers}
                    tickets={tickets}
                    onSelectTicket={(id) => setSelectedTicketId(id)}
                    onCreateCustomer={handleCreateCustomer}
                    onUpdateCustomer={handleUpdateCustomer}
                    onDeleteCustomer={handleDeleteCustomer}
                  />
                )}

                {/* Module: Support Agents */}
                {currentModule === 'agents' && (
                  <AgentList
                    agents={agents}
                    tickets={tickets}
                    onSelectTicket={(id) => setSelectedTicketId(id)}
                    onCreateAgent={handleCreateAgent}
                    onUpdateAgent={handleUpdateAgent}
                    onDeleteAgent={handleDeleteAgent}
                  />
                )}

                {/* Module: Categories */}
                {currentModule === 'categories' && (
                  <CategoryList
                    categories={categories}
                    tickets={tickets}
                    onCreateCategory={handleCreateCategory}
                    onUpdateCategory={handleUpdateCategory}
                    onDeleteCategory={handleDeleteCategory}
                  />
                )}

                {/* Module: Reports */}
                {currentModule === 'reports' && (
                  <ReportsView
                    tickets={tickets}
                    agents={agents}
                    customers={customers}
                    categories={categories}
                  />
                )}

                {/* Module: Settings & Testing */}
                {currentModule === 'settings' && (
                  <SettingsView
                    customers={customers}
                    agents={agents}
                    tickets={tickets}
                    categories={categories}
                    activeRole={activeRole}
                    onResetData={handleResetData}
                    onExportJson={handleExportJson}
                  />
                )}
              </>
            )}
          </div>
        </main>
      </div>

      {/* Ticket Create Modal */}
      <TicketCreateModal
        isOpen={createTicketOpen}
        onClose={() => setCreateTicketOpen(false)}
        customers={customers}
        agents={agents}
        categories={categories}
        onSubmit={handleCreateTicket}
      />

      {/* Salesforce Concepts Educational Guide */}
      <SalesforceConceptsModal
        isOpen={conceptsOpen}
        onClose={() => setConceptsOpen(false)}
      />

      {/* Floating Toast Notification */}
      {toast && (
        <div
          id="app-toast"
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl border text-sm font-medium animate-in slide-in-from-bottom-5 duration-200 ${
            toast.type === 'success'
              ? 'bg-emerald-900 text-emerald-100 border-emerald-700'
              : toast.type === 'error'
              ? 'bg-rose-900 text-rose-100 border-rose-700'
              : 'bg-slate-900 text-slate-100 border-slate-700'
          }`}
        >
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
          {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
          {toast.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
          <span className="leading-snug">{toast.message}</span>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="p-1 hover:bg-white/10 rounded ml-2"
          >
            <X className="w-3.5 h-3.5 opacity-70 hover:opacity-100" />
          </button>
        </div>
      )}
    </div>
  );
}
