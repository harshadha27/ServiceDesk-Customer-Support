import { TicketPriority, TicketStatus, Agent, Ticket, SLAStatus } from '../types';

/**
 * ServiceDesk CRM Automation Engine
 * Mimics Salesforce Flow, Case Assignment Rules, and Validation Rules
 */

// SLA hours based on Priority
export const SLA_HOURS_MAP: Record<TicketPriority, number> = {
  Critical: 4,
  High: 8,
  Medium: 24,
  Low: 48,
};

/**
 * Calculate due date based on priority SLA rules
 * (Salesforce Concept: Entitlement Management & Milestones / Formula Field)
 */
export function calculateDueDate(priority: TicketPriority, baseDate: Date | string = new Date()): string {
  const hours = SLA_HOURS_MAP[priority] || 24;
  const base = typeof baseDate === 'string' ? new Date(baseDate) : baseDate;
  const due = new Date(base.getTime() + hours * 3600000);
  return due.toISOString();
}

/**
 * Calculate real-time SLA health status
 */
export function calculateSlaStatus(ticket: Ticket): SLAStatus {
  if (ticket.status === 'Resolved' || ticket.status === 'Closed') {
    return {
      state: 'Resolved',
      hoursRemaining: 0,
      percentageUsed: 100,
    };
  }

  const now = Date.now();
  const created = new Date(ticket.createdDate).getTime();
  const due = new Date(ticket.dueDate).getTime();
  const totalDuration = Math.max(due - created, 1);
  const elapsed = now - created;
  const remainingMs = due - now;
  const hoursRemaining = Math.round((remainingMs / 3600000) * 10) / 10;
  const percentageUsed = Math.min(Math.round((elapsed / totalDuration) * 100), 100);

  if (remainingMs <= 0) {
    return {
      state: 'Overdue',
      hoursRemaining,
      percentageUsed: 100,
    };
  }

  // If less than 2 hours or <= 25% SLA remaining, mark "Due Soon"
  if (hoursRemaining <= 2 || percentageUsed >= 75) {
    return {
      state: 'Due Soon',
      hoursRemaining,
      percentageUsed,
    };
  }

  return {
    state: 'On Track',
    hoursRemaining,
    percentageUsed,
  };
}

/**
 * Ticket Assignment Automation
 * (Salesforce Concept: Case Assignment Rules & Omni-Channel Routing)
 * 1. Filters for available agents
 * 2. Matches category skill where applicable
 * 3. Prefers agent with fewest active tickets
 */
export function executeTicketAssignment(
  category: string,
  agents: Agent[]
): { agent: Agent | null; rationale: string; reason?: string } {
  // 1. Available agents only
  const available = agents.filter((a) => a.availability === 'Available');

  if (available.length === 0) {
    return {
      agent: null,
      rationale: 'No agents currently marked as Available. Placed in default unassigned queue.',
      reason: 'No agents available',
    };
  }

  // 2. Skill match (check against array of skills or single skill)
  const skillMatches = available.filter((a) => {
    if (Array.isArray(a.skills)) {
      return a.skills.some((s) => s.toLowerCase().includes(category.toLowerCase()) || category.toLowerCase().includes(s.toLowerCase()));
    }
    return false;
  });

  const candidatePool = skillMatches.length > 0 ? skillMatches : available;

  // 3. Lowest active ticket workload
  candidatePool.sort((a, b) => a.activeTickets - b.activeTickets);
  const selectedAgent = candidatePool[0];

  const rationale = skillMatches.length > 0
    ? `Assigned to ${selectedAgent.fullName} based on certified skill match and lowest active workload (${selectedAgent.activeTickets} tickets).`
    : `Assigned to ${selectedAgent.fullName} based on general queue capacity and lowest active workload (${selectedAgent.activeTickets} tickets).`;

  return {
    agent: selectedAgent,
    rationale,
    reason: skillMatches.length > 0 ? 'Skill match & capacity' : 'General availability',
  };
}

// Alias for assignment
export const autoAssignTicket = executeTicketAssignment;

/**
 * Validate resolution notes on ticket completion
 */
export function validateResolutionNotes(status: TicketStatus, notes?: string | null): { valid: boolean; error?: string } {
  if (status === 'Resolved' || status === 'Closed') {
    if (!notes || notes.trim().length < 5) {
      return {
        valid: false,
        error: 'Validation Rule: Resolution Notes are mandatory (minimum 5 characters) before marking a ticket as Resolved.',
      };
    }
  }
  return { valid: true };
}

/**
 * Check if a ticket can be reopened
 */
export function canReopenTicket(status: TicketStatus): boolean {
  return status === 'Resolved' || status === 'Closed';
}

/**
 * Status Workflow Rules & Validations
 * (Salesforce Concept: Support Processes, Path, and Validation Rules)
 */
export const ALLOWED_TRANSITIONS: Record<TicketStatus, TicketStatus[]> = {
  New: ['Open'],
  Open: ['In Progress'],
  'In Progress': ['Waiting for Customer', 'Resolved'],
  'Waiting for Customer': ['In Progress', 'Resolved'],
  Resolved: ['Closed', 'Open'], // Open represents Reopen
  Closed: ['Open'], // Open represents Reopen
};

export function validateStatusTransition(
  currentStatus: TicketStatus,
  targetStatus: TicketStatus,
  resolutionNotes?: string
): { isValid: boolean; valid: boolean; error?: string } {
  if (currentStatus === targetStatus) {
    return { isValid: true, valid: true };
  }

  const allowed = ALLOWED_TRANSITIONS[currentStatus] || [];
  if (!allowed.includes(targetStatus)) {
    return {
      isValid: false,
      valid: false,
      error: `Invalid status workflow transition: Cannot move directly from "${currentStatus}" to "${targetStatus}". Please follow the approved CRM lifecycle.`,
    };
  }

  if (targetStatus === 'Resolved' && (!resolutionNotes || resolutionNotes.trim().length < 5)) {
    return {
      isValid: false,
      valid: false,
      error: 'Validation Rule: Resolution Notes are mandatory (minimum 5 characters) before marking a ticket as Resolved.',
    };
  }

  return { isValid: true, valid: true };
}

/**
 * Generate sequential IDs
 */
export function generateNextId(prefix: string, existingList: { id: string }[]): string {
  const nums = existingList
    .map((item) => {
      const parts = item.id.split('-');
      const n = parseInt(parts[1], 10);
      return isNaN(n) ? 0 : n;
    })
    .filter((n) => n > 0);

  const max = nums.length > 0 ? Math.max(...nums) : 1000;
  return `${prefix}-${max + 1}`;
}
