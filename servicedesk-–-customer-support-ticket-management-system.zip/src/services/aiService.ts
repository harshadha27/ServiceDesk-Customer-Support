import { AIAssistantResult, TicketPriority } from '../types';

export interface AIResponsePayload {
  success: boolean;
  aiGenerated: boolean;
  source: string;
  data: AIAssistantResult;
}

export async function requestAITicketAssistant(params: {
  subject: string;
  description: string;
  customerName?: string;
  currentCategory?: string;
  currentPriority?: TicketPriority;
}): Promise<AIAssistantResult> {
  const response = await fetch('/api/ai/ticket-assistant', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errJson = await response.json().catch(() => ({}));
    throw new Error(errJson.error || `Server responded with status ${response.status}`);
  }

  const result: AIResponsePayload = await response.json();
  return result.data;
}
