import {
  Customer,
  Agent,
  Ticket,
  TicketCategory,
  TicketComment,
  TicketHistoryItem,
  TicketStatus,
  TicketPriority,
  UserRole,
} from '../types';
import {
  INITIAL_CUSTOMERS,
  INITIAL_AGENTS,
  INITIAL_CATEGORIES,
  INITIAL_TICKETS,
  INITIAL_COMMENTS,
  INITIAL_HISTORY,
} from '../data/initialData';
import {
  calculateDueDate,
  executeTicketAssignment,
  validateStatusTransition,
  generateNextId,
} from './automationService';

const STORAGE_KEYS = {
  CUSTOMERS: 'servicedesk_customers',
  AGENTS: 'servicedesk_agents',
  CATEGORIES: 'servicedesk_categories',
  TICKETS: 'servicedesk_tickets',
  COMMENTS: 'servicedesk_comments',
  HISTORY: 'servicedesk_history',
  ACTIVE_ROLE: 'servicedesk_active_role',
};

function getStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.warn(`Failed to parse localStorage key ${key}`, e);
    return fallback;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event('servicedesk_data_changed'));
  } catch (e) {
    console.error(`Failed to store localStorage key ${key}`, e);
  }
}

class StorageService {
  // --- Initialization & Reset ---
  init(): void {
    if (!localStorage.getItem(STORAGE_KEYS.CUSTOMERS)) {
      this.resetAllData();
    } else {
      // Re-reconcile agent active ticket counts
      this.reconcileAgentWorkloads();
    }
  }

  resetAllData(): void {
    setStored(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    setStored(STORAGE_KEYS.AGENTS, INITIAL_AGENTS);
    setStored(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
    setStored(STORAGE_KEYS.TICKETS, INITIAL_TICKETS);
    setStored(STORAGE_KEYS.COMMENTS, INITIAL_COMMENTS);
    setStored(STORAGE_KEYS.HISTORY, INITIAL_HISTORY);
    this.reconcileAgentWorkloads();
  }

  // --- Active Role Management ---
  getActiveRole(): UserRole {
    return getStored<UserRole>(STORAGE_KEYS.ACTIVE_ROLE, 'Admin');
  }

  setActiveRole(role: UserRole): void {
    setStored(STORAGE_KEYS.ACTIVE_ROLE, role);
  }

  // --- Customers ---
  getCustomers(): Customer[] {
    return getStored<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
  }

  getCustomerById(id: string): Customer | undefined {
    return this.getCustomers().find((c) => c.id === id);
  }

  saveCustomer(customer: Omit<Customer, 'id' | 'createdDate'> & { id?: string }): { success: boolean; customer?: Customer; error?: string } {
    const list = this.getCustomers();
    if (!customer.fullName || !customer.email || !customer.company) {
      return { success: false, error: 'Full Name, Email, and Company are required.' };
    }

    if (customer.id) {
      // Edit
      const index = list.findIndex((c) => c.id === customer.id);
      if (index === -1) return { success: false, error: 'Customer not found.' };
      const updated: Customer = {
        ...list[index],
        ...customer,
      };
      list[index] = updated;
      setStored(STORAGE_KEYS.CUSTOMERS, list);
      return { success: true, customer: updated };
    } else {
      // Create
      const newId = generateNextId('CUST', list);
      const newCust: Customer = {
        ...customer,
        id: newId,
        createdDate: new Date().toISOString(),
        status: customer.status || 'Active',
      };
      list.unshift(newCust);
      setStored(STORAGE_KEYS.CUSTOMERS, list);
      return { success: true, customer: newCust };
    }
  }

  deleteCustomer(id: string): { success: boolean; error?: string } {
    // Check if customer has open tickets
    const tickets = this.getTicketsByCustomer(id);
    const openTickets = tickets.filter((t) => t.status !== 'Closed');
    if (openTickets.length > 0) {
      return {
        success: false,
        error: `Cannot delete customer: ${openTickets.length} open/in-progress ticket(s) exist. Please resolve or close them first. (Salesforce Cascade Delete Protection)`,
      };
    }

    const list = this.getCustomers().filter((c) => c.id !== id);
    setStored(STORAGE_KEYS.CUSTOMERS, list);
    return { success: true };
  }

  // --- Support Agents ---
  getAgents(): Agent[] {
    return getStored<Agent[]>(STORAGE_KEYS.AGENTS, INITIAL_AGENTS);
  }

  getAgentById(id: string): Agent | undefined {
    return this.getAgents().find((a) => a.id === id);
  }

  saveAgent(agent: Omit<Agent, 'id' | 'createdDate' | 'activeTickets'> & { id?: string }): { success: boolean; agent?: Agent; error?: string } {
    const list = this.getAgents();
    if (!agent.fullName || !agent.email || !agent.department || !agent.skill) {
      return { success: false, error: 'Full Name, Email, Department, and Primary Skill are mandatory.' };
    }

    if (agent.id) {
      const index = list.findIndex((a) => a.id === agent.id);
      if (index === -1) return { success: false, error: 'Agent not found.' };
      const updated: Agent = {
        ...list[index],
        ...agent,
      };
      list[index] = updated;
      setStored(STORAGE_KEYS.AGENTS, list);
      return { success: true, agent: updated };
    } else {
      const newId = generateNextId('AGT', list);
      const newAgent: Agent = {
        ...agent,
        id: newId,
        activeTickets: 0,
        createdDate: new Date().toISOString(),
      };
      list.push(newAgent);
      setStored(STORAGE_KEYS.AGENTS, list);
      return { success: true, agent: newAgent };
    }
  }

  toggleAgentAvailability(id: string, availability: Agent['availability']): void {
    const list = this.getAgents();
    const agent = list.find((a) => a.id === id);
    if (agent) {
      agent.availability = availability;
      setStored(STORAGE_KEYS.AGENTS, list);
    }
  }

  reconcileAgentWorkloads(): void {
    const tickets = getStored<Ticket[]>(STORAGE_KEYS.TICKETS, INITIAL_TICKETS);
    const agents = getStored<Agent[]>(STORAGE_KEYS.AGENTS, INITIAL_AGENTS);

    // Active tickets are those that are NOT Resolved or Closed
    const activeCounts: Record<string, number> = {};
    tickets.forEach((t) => {
      if (t.assignedAgentId && t.status !== 'Resolved' && t.status !== 'Closed') {
        activeCounts[t.assignedAgentId] = (activeCounts[t.assignedAgentId] || 0) + 1;
      }
    });

    agents.forEach((a) => {
      a.activeTickets = activeCounts[a.id] || 0;
    });

    setStored(STORAGE_KEYS.AGENTS, agents);
  }

  // --- Categories ---
  getCategories(): TicketCategory[] {
    return getStored<TicketCategory[]>(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
  }

  saveCategory(cat: Omit<TicketCategory, 'id'> & { id?: string }): { success: boolean; category?: TicketCategory; error?: string } {
    const list = this.getCategories();
    if (!cat.name || !cat.description) {
      return { success: false, error: 'Category Name and Description are required.' };
    }

    if (cat.id) {
      const index = list.findIndex((c) => c.id === cat.id);
      if (index === -1) return { success: false, error: 'Category not found.' };
      list[index] = { ...list[index], ...cat };
      setStored(STORAGE_KEYS.CATEGORIES, list);
      return { success: true, category: list[index] };
    } else {
      const newId = generateNextId('CAT', list);
      const newCat: TicketCategory = {
        ...cat,
        id: newId,
        defaultPriority: cat.defaultPriority || 'Medium',
        slaHours: cat.slaHours || 24,
      };
      list.push(newCat);
      setStored(STORAGE_KEYS.CATEGORIES, list);
      return { success: true, category: newCat };
    }
  }

  deleteCategory(id: string): { success: boolean; error?: string } {
    const tickets = this.getTickets().filter((t) => {
      const cat = this.getCategories().find((c) => c.id === id);
      return cat && t.category === cat.name;
    });
    if (tickets.length > 0) {
      return {
        success: false,
        error: `Cannot delete category: ${tickets.length} ticket(s) are actively categorized under it.`,
      };
    }
    const list = this.getCategories().filter((c) => c.id !== id);
    setStored(STORAGE_KEYS.CATEGORIES, list);
    return { success: true };
  }

  // --- Tickets ---
  getTickets(): Ticket[] {
    return getStored<Ticket[]>(STORAGE_KEYS.TICKETS, INITIAL_TICKETS);
  }

  getTicketById(id: string): Ticket | undefined {
    return this.getTickets().find((t) => t.id === id);
  }

  getTicketsByCustomer(customerId: string): Ticket[] {
    return this.getTickets().filter((t) => t.customerId === customerId);
  }

  getTicketsByAgent(agentId: string): Ticket[] {
    return this.getTickets().filter((t) => t.assignedAgentId === agentId);
  }

  createTicket(payload: {
    subject: string;
    description: string;
    customerId: string;
    category: string;
    priority: TicketPriority;
    assignedAgentId?: string | null;
    dueDate?: string;
  }): { success: boolean; ticket?: Ticket; error?: string; assignmentNote?: string } {
    // Mandatory Validation
    if (!payload.subject || payload.subject.trim().length === 0) {
      return { success: false, error: 'Validation Rule: Ticket Subject cannot be empty.' };
    }
    if (!payload.description || payload.description.trim().length === 0) {
      return { success: false, error: 'Validation Rule: Ticket Description cannot be empty.' };
    }
    if (!payload.customerId) {
      return { success: false, error: 'Validation Rule: Customer selection is required.' };
    }
    if (!payload.category) {
      return { success: false, error: 'Validation Rule: Category selection is required.' };
    }
    if (!payload.priority) {
      return { success: false, error: 'Validation Rule: Priority selection is required.' };
    }

    const customer = this.getCustomerById(payload.customerId);
    if (!customer) {
      return { success: false, error: 'Invalid Customer reference.' };
    }

    const tickets = this.getTickets();
    const agents = this.getAgents();
    const newId = generateNextId('TCK', tickets);
    const nowIso = new Date().toISOString();

    // Assignment Automation Logic (Salesforce Case Assignment Rules)
    let assignedAgentId: string | null = null;
    let assignedAgentName: string | null = null;
    let assignmentNote = '';

    if (payload.assignedAgentId) {
      // Explicit manual assignment
      const agent = this.getAgentById(payload.assignedAgentId);
      if (agent) {
        assignedAgentId = agent.id;
        assignedAgentName = agent.fullName;
        assignmentNote = `Manually assigned to ${agent.fullName}.`;
      }
    } else {
      // Run automatic assignment rule
      const { agent, rationale } = executeTicketAssignment(payload.category, agents);
      if (agent) {
        assignedAgentId = agent.id;
        assignedAgentName = agent.fullName;
        assignmentNote = rationale;
      } else {
        assignmentNote = 'No available agent found matching skills/capacity. Queued as Waiting for Assignment.';
      }
    }

    const dueDate = payload.dueDate || calculateDueDate(payload.priority);

    const newTicket: Ticket = {
      id: newId,
      subject: payload.subject.trim(),
      description: payload.description.trim(),
      customerId: customer.id,
      customerName: customer.fullName,
      customerEmail: customer.email,
      assignedAgentId,
      assignedAgentName,
      category: payload.category,
      priority: payload.priority,
      status: 'New',
      createdDate: nowIso,
      updatedDate: nowIso,
      dueDate,
      resolutionDate: null,
    };

    tickets.unshift(newTicket);
    setStored(STORAGE_KEYS.TICKETS, tickets);

    // Record initial history
    this.addHistoryItem(newId, 'Status', 'None', 'New', 'System (Case Creation)');
    if (assignedAgentName) {
      this.addHistoryItem(newId, 'Assigned Agent', 'Unassigned', assignedAgentName, 'Case Assignment Rule');
    }

    // Refresh agent active ticket counts
    this.reconcileAgentWorkloads();

    return {
      success: true,
      ticket: newTicket,
      assignmentNote,
    };
  }

  updateTicketStatus(
    ticketId: string,
    newStatus: TicketStatus,
    changedBy = 'Support User',
    resolutionNotes?: string
  ): { success: boolean; ticket?: Ticket; error?: string } {
    const tickets = this.getTickets();
    const ticket = tickets.find((t) => t.id === ticketId);
    if (!ticket) {
      return { success: false, error: 'Ticket not found.' };
    }

    const validation = validateStatusTransition(ticket.status, newStatus, resolutionNotes);
    if (!validation.isValid) {
      return { success: false, error: validation.error };
    }

    const oldStatus = ticket.status;
    const nowIso = new Date().toISOString();

    ticket.status = newStatus;
    ticket.updatedDate = nowIso;

    if (newStatus === 'Resolved') {
      ticket.resolutionDate = nowIso;
      if (resolutionNotes) ticket.resolutionNotes = resolutionNotes.trim();
    } else if (newStatus === 'Closed') {
      // Retain resolution date
      if (!ticket.resolutionDate) ticket.resolutionDate = nowIso;
      if (resolutionNotes) ticket.resolutionNotes = resolutionNotes.trim();
    } else if (oldStatus === 'Resolved' || oldStatus === 'Closed') {
      // Reopening ticket
      ticket.resolutionDate = null;
    }

    setStored(STORAGE_KEYS.TICKETS, tickets);
    this.addHistoryItem(ticketId, 'Status', oldStatus, newStatus, changedBy);
    this.reconcileAgentWorkloads();

    return { success: true, ticket };
  }

  updateTicketPriority(
    ticketId: string,
    newPriority: TicketPriority,
    changedBy = 'Support User'
  ): { success: boolean; ticket?: Ticket; error?: string } {
    const tickets = this.getTickets();
    const ticket = tickets.find((t) => t.id === ticketId);
    if (!ticket) {
      return { success: false, error: 'Ticket not found.' };
    }

    const oldPriority = ticket.priority;
    if (oldPriority === newPriority) return { success: true, ticket };

    ticket.priority = newPriority;
    ticket.updatedDate = new Date().toISOString();
    // Recalculate SLA due date based on new priority
    ticket.dueDate = calculateDueDate(newPriority, new Date(ticket.createdDate));

    setStored(STORAGE_KEYS.TICKETS, tickets);
    this.addHistoryItem(ticketId, 'Priority', oldPriority, newPriority, changedBy);

    return { success: true, ticket };
  }

  reassignTicket(
    ticketId: string,
    newAgentId: string | null,
    changedBy = 'Support User'
  ): { success: boolean; ticket?: Ticket; error?: string } {
    const tickets = this.getTickets();
    const ticket = tickets.find((t) => t.id === ticketId);
    if (!ticket) return { success: false, error: 'Ticket not found.' };

    const oldAgent = ticket.assignedAgentName || 'Unassigned';
    let newAgentName: string | null = null;

    if (newAgentId) {
      const agent = this.getAgentById(newAgentId);
      if (!agent) return { success: false, error: 'Target agent not found.' };
      ticket.assignedAgentId = agent.id;
      ticket.assignedAgentName = agent.fullName;
      newAgentName = agent.fullName;
    } else {
      ticket.assignedAgentId = null;
      ticket.assignedAgentName = null;
      newAgentName = 'Unassigned';
    }

    ticket.updatedDate = new Date().toISOString();
    setStored(STORAGE_KEYS.TICKETS, tickets);
    this.addHistoryItem(ticketId, 'Assigned Agent', oldAgent, newAgentName, changedBy);
    this.reconcileAgentWorkloads();

    return { success: true, ticket };
  }

  // --- Comments ---
  getComments(ticketId?: string): TicketComment[] {
    const all = getStored<TicketComment[]>(STORAGE_KEYS.COMMENTS, INITIAL_COMMENTS);
    if (!ticketId) return all;
    return all
      .filter((c) => c.ticketId === ticketId)
      .sort((a, b) => new Date(a.createdDate).getTime() - new Date(b.createdDate).getTime());
  }

  addComment(
    ticketIdOrObj: string | { ticketId: string; author: string; comment: string; isInternal?: boolean },
    authorArg?: string,
    commentArg?: string,
    isInternalArg = false
  ): { success: boolean; comment?: TicketComment; error?: string } {
    let ticketId: string;
    let author: string;
    let comment: string;
    let isInternal = isInternalArg;

    if (typeof ticketIdOrObj === 'object') {
      ticketId = ticketIdOrObj.ticketId;
      author = ticketIdOrObj.author;
      comment = ticketIdOrObj.comment;
      isInternal = ticketIdOrObj.isInternal ?? false;
    } else {
      ticketId = ticketIdOrObj;
      author = authorArg || 'Support Agent';
      comment = commentArg || '';
    }

    if (!comment || comment.trim().length === 0) {
      return { success: false, error: 'Comment text cannot be empty.' };
    }

    const all = getStored<TicketComment[]>(STORAGE_KEYS.COMMENTS, INITIAL_COMMENTS);
    const newId = generateNextId('COM', all);
    const newComment: TicketComment = {
      id: newId,
      ticketId,
      author,
      comment: comment.trim(),
      createdDate: new Date().toISOString(),
      isInternal,
    };

    all.push(newComment);
    setStored(STORAGE_KEYS.COMMENTS, all);
    this.addHistoryItem(ticketId, 'Comments', 'N/A', `Added comment by ${author}`, author);

    return { success: true, comment: newComment };
  }

  // --- History / Timeline ---
  getHistory(ticketId?: string): TicketHistoryItem[] {
    const all = getStored<TicketHistoryItem[]>(STORAGE_KEYS.HISTORY, INITIAL_HISTORY);
    if (!ticketId) return all;
    return all
      .filter((h) => h.ticketId === ticketId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  // Aliases for CRUD compatibility
  createCustomer(data: Omit<Customer, 'id' | 'createdDate'>) {
    return this.saveCustomer(data);
  }

  updateCustomer(id: string, updates: Partial<Customer>) {
    return this.saveCustomer({ ...updates, id } as any);
  }

  createAgent(data: Omit<Agent, 'id' | 'activeTickets'>) {
    return this.saveAgent(data as any);
  }

  updateAgent(id: string, updates: Partial<Agent>) {
    return this.saveAgent({ ...updates, id } as any);
  }

  deleteAgent(id: string): { success: boolean; error?: string } {
    const tickets = this.getTicketsByAgent(id);
    const activeTickets = tickets.filter((t) => t.status !== 'Closed');
    if (activeTickets.length > 0) {
      return {
        success: false,
        error: `Cannot delete agent: ${activeTickets.length} active case(s) currently assigned. Please reassign their workload first.`,
      };
    }
    const list = this.getAgents().filter((a) => a.id !== id);
    setStored(STORAGE_KEYS.AGENTS, list);
    return { success: true };
  }

  createCategory(data: { name: string; description: string; defaultPriority?: TicketPriority; slaHours?: number }) {
    return this.saveCategory(data as any);
  }

  updateCategory(id: string, updates: Partial<TicketCategory>) {
    return this.saveCategory({ ...updates, id } as any);
  }

  reassignTicketAgent(ticketId: string, agentId: string | null, changedBy = 'Support User') {
    return this.reassignTicket(ticketId, agentId, changedBy);
  }

  resetToDefaults() {
    this.resetAllData();
  }

  exportAllData(): string {
    return JSON.stringify(
      {
        customers: this.getCustomers(),
        agents: this.getAgents(),
        categories: this.getCategories(),
        tickets: this.getTickets(),
        comments: this.getComments(),
        history: this.getHistory(),
      },
      null,
      2
    );
  }

  private addHistoryItem(
    ticketId: string,
    fieldChanged: string,
    oldValue: string,
    newValue: string,
    changedBy: string
  ): void {
    const all = getStored<TicketHistoryItem[]>(STORAGE_KEYS.HISTORY, INITIAL_HISTORY);
    const newId = generateNextId('HIST', all);
    all.push({
      id: newId,
      ticketId,
      fieldChanged,
      oldValue,
      newValue,
      changedBy,
      timestamp: new Date().toISOString(),
    });
    setStored(STORAGE_KEYS.HISTORY, all);
  }
}

export const storageService = new StorageService();
// Initialize immediately on bundle load
storageService.init();
