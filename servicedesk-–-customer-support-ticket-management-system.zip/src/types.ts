/**
 * ServiceDesk – Customer Support Ticket Management System
 * Core TypeScript Data Models & Salesforce Concept Mapping
 */

export type CustomerStatus = 'Active' | 'Inactive';

export interface Customer {
  id: string; // e.g. "CUST-1001"
  fullName: string;
  email: string;
  phone: string;
  company: string;
  industry: string;
  location: string;
  status: CustomerStatus;
  createdDate: string; // ISO 8601 string
}

export type AgentAvailability = 'Available' | 'Busy' | 'Offline';
export type AgentRole = 'Support Agent' | 'Senior Specialist' | 'Lead Engineer' | 'Support Manager';
export type UserRole = 'Admin' | 'Support Manager' | 'Support Agent';

export interface Agent {
  id: string; // e.g. "AGT-201"
  fullName: string;
  email: string;
  department: string;
  role: AgentRole;
  availability: AgentAvailability;
  skill: string; // e.g. "Technical Issue", "Billing", "Account", "General Support"
  skills?: string[]; // array representation of skills
  activeTickets: number; // dynamically maintained and stored
  createdDate: string;
}

export type TicketPriority = 'Low' | 'Medium' | 'High' | 'Critical';
export type TicketStatus = 'New' | 'Open' | 'In Progress' | 'Waiting for Customer' | 'Resolved' | 'Closed';

export interface TicketCategory {
  id: string; // e.g. "CAT-01"
  name: string; // e.g. "Technical Issue"
  description: string;
  defaultPriority: TicketPriority;
  slaHours: number;
}

export interface Ticket {
  id: string; // e.g. "TCK-3001"
  subject: string;
  description: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  assignedAgentId: string | null; // null if unassigned / Waiting for Assignment
  assignedAgentName: string | null;
  category: string;
  priority: TicketPriority;
  status: TicketStatus;
  createdDate: string;
  updatedDate: string;
  dueDate: string; // SLA based
  resolutionDate?: string | null;
  resolutionNotes?: string;
}

export interface TicketComment {
  id: string;
  ticketId: string;
  author: string;
  authorRole?: string;
  comment: string;
  createdDate: string;
  isInternal?: boolean;
}

export interface TicketHistoryItem {
  id: string;
  ticketId: string;
  fieldChanged: string;
  oldValue: string;
  newValue: string;
  changedBy: string;
  timestamp: string;
}

export interface SLAStatus {
  state: 'On Track' | 'Due Soon' | 'Overdue' | 'Resolved';
  hoursRemaining: number;
  percentageUsed: number;
}

export interface AIAssistantResult {
  issueSummary: string;
  suggestedCategory: string;
  suggestedPriority: TicketPriority;
  priorityRationale: string;
  suggestedResponse: string;
  keyIssue: string;
  suggestedAction: string;
}

export interface TestCaseResult {
  id: string;
  title: string;
  description: string;
  category: 'Validation' | 'Automation' | 'Relationships' | 'SLA' | 'Workflow' | 'Reporting';
  status: 'passed' | 'failed' | 'running' | 'idle';
  detail?: string;
}
