import React, { useState, useMemo } from 'react';
import { Customer, Ticket } from '../../types';
import { CustomerStatusBadge, StatusBadge, PriorityBadge } from '../common/Badges';
import { Modal, ConfirmDialog } from '../common/Modal';
import {
  Users,
  Plus,
  Search,
  Building2,
  Mail,
  Phone,
  Edit2,
  Trash2,
  Eye,
  LifeBuoy,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

interface CustomerListProps {
  customers: Customer[];
  tickets: Ticket[];
  onSelectTicket: (ticketId: string) => void;
  onCreateCustomer: (customer: Omit<Customer, 'id' | 'createdDate'>) => { success: boolean; error?: string };
  onUpdateCustomer: (id: string, updates: Partial<Customer>) => { success: boolean; error?: string };
  onDeleteCustomer: (id: string) => { success: boolean; error?: string };
}

export function CustomerList({
  customers,
  tickets,
  onSelectTicket,
  onCreateCustomer,
  onUpdateCustomer,
  onDeleteCustomer,
}: CustomerListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  // Create / Edit Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    industry: 'Technology',
    location: 'United States',
    status: 'Active' as Customer['status'],
  });
  const [formError, setFormError] = useState<string | null>(null);

  // Delete Confirm Dialog
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const filteredCustomers = useMemo(() => {
    if (!searchTerm.trim()) return customers;
    const q = searchTerm.toLowerCase();
    return customers.filter(
      (c) =>
        c.fullName.toLowerCase().includes(q) ||
        c.company.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q)
    );
  }, [customers, searchTerm]);

  // Selected customer for detail drawer/modal
  const activeCustomer = useMemo(() => {
    return customers.find((c) => c.id === selectedCustomerId) || null;
  }, [customers, selectedCustomerId]);

  // Tickets associated with the selected customer (Lookup Relationship)
  const activeCustomerTickets = useMemo(() => {
    if (!activeCustomer) return [];
    return tickets.filter((t) => t.customerId === activeCustomer.id);
  }, [tickets, activeCustomer]);

  const handleOpenCreate = () => {
    setEditingCustomer(null);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      company: '',
      industry: 'Technology',
      location: 'United States',
      status: 'Active',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (cust: Customer) => {
    setEditingCustomer(cust);
    setFormData({
      fullName: cust.fullName,
      email: cust.email,
      phone: cust.phone,
      company: cust.company,
      industry: cust.industry || 'Technology',
      location: cust.location || 'United States',
      status: cust.status,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Validation Rules
    if (!formData.fullName.trim()) {
      setFormError('Validation Rule: Full Name is required.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setFormError('Validation Rule: Valid email format is required.');
      return;
    }
    if (!formData.company.trim()) {
      setFormError('Validation Rule: Company / Account Name is required.');
      return;
    }

    if (editingCustomer) {
      const res = onUpdateCustomer(editingCustomer.id, formData);
      if (res.success) {
        setIsModalOpen(false);
      } else {
        setFormError(res.error || 'Failed to update customer');
      }
    } else {
      const res = onCreateCustomer(formData);
      if (res.success) {
        setIsModalOpen(false);
      } else {
        setFormError(res.error || 'Failed to create customer');
      }
    }
  };

  const handleConfirmDelete = () => {
    if (!customerToDelete) return;
    const res = onDeleteCustomer(customerToDelete.id);
    if (!res.success) {
      setDeleteError(res.error || 'Cannot delete customer.');
    } else {
      setCustomerToDelete(null);
      setDeleteConfirmOpen(false);
      if (selectedCustomerId === customerToDelete.id) {
        setSelectedCustomerId(null);
      }
    }
  };

  return (
    <div id="customers-view" className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Customers (Accounts & Contacts)</h1>
            <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full border border-slate-200">
              {customers.length} Accounts
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Maintain customer directories, contact coordinates, and view linked support tickets via Lookup relationships.
          </p>
        </div>

        <button
          id="btn-create-customer"
          type="button"
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>New Customer</span>
        </button>
      </div>

      {deleteError && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs font-medium text-rose-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{deleteError}</span>
          </div>
          <button type="button" onClick={() => setDeleteError(null)} className="text-rose-600 hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Search & Filter */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between gap-4">
        <div className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="search-customer-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search customers by name, company, email, phone..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
        <span className="text-xs text-slate-500">
          Showing {filteredCustomers.length} of {customers.length}
        </span>
      </div>

      {/* Customers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredCustomers.map((c) => {
          const custTickets = tickets.filter((t) => t.customerId === c.id);
          const openTickets = custTickets.filter((t) => t.status !== 'Closed' && t.status !== 'Resolved').length;

          return (
            <div
              key={c.id}
              id={`customer-card-${c.id}`}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-blue-300 hover:shadow-sm transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">{c.fullName}</h3>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5 font-medium">
                      <Building2 className="w-3 h-3 text-slate-400" />
                      <span>{c.company}</span>
                    </p>
                  </div>
                  <CustomerStatusBadge status={c.status} />
                </div>

                <div className="space-y-1.5 text-xs text-slate-600 pt-1">
                  <p className="flex items-center gap-2 truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono">{c.email}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{c.phone}</span>
                  </p>
                </div>
              </div>

              {/* Related Tickets Mini Stats */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <LifeBuoy className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-slate-700">
                    {custTickets.length} Tickets ({openTickets} Open)
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setSelectedCustomerId(c.id)}
                    className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="View Customer Details & Cases"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(c)}
                    className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="Edit Customer"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomerToDelete(c);
                      setDeleteError(null);
                      setDeleteConfirmOpen(true);
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="Delete Customer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Customer Details Modal (Shows Related Cases via Lookup Relationship) */}
      {activeCustomer && (
        <Modal
          isOpen={!!activeCustomer}
          onClose={() => setSelectedCustomerId(null)}
          title={`Customer Record: ${activeCustomer.fullName}`}
          subtitle="Lookup Relationship: All linked support cases for this account"
          maxWidth="xl"
        >
          <div className="space-y-6">
            {/* Contact Details Card */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="font-semibold text-slate-500 block">Account / Company</span>
                <span className="font-bold text-slate-900 mt-0.5 block">{activeCustomer.company}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Email Address</span>
                <span className="font-mono text-slate-800 mt-0.5 block">{activeCustomer.email}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Phone</span>
                <span className="text-slate-800 mt-0.5 block">{activeCustomer.phone}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Status</span>
                <div className="mt-0.5">
                  <CustomerStatusBadge status={activeCustomer.status} />
                </div>
              </div>
            </div>

            {/* Related Tickets Table */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <LifeBuoy className="w-4 h-4 text-blue-600" />
                  <span>Related Support Cases ({activeCustomerTickets.length})</span>
                </h3>
                <span className="text-xs text-slate-500">Salesforce Related List</span>
              </div>

              {activeCustomerTickets.length === 0 ? (
                <div className="p-8 text-center text-slate-500 border border-slate-200 rounded-xl bg-white">
                  No tickets logged for this customer yet.
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                        <th className="py-2.5 px-3">Case ID</th>
                        <th className="py-2.5 px-3">Subject</th>
                        <th className="py-2.5 px-3">Priority</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Due Date</th>
                        <th className="py-2.5 px-3 text-right">View</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {activeCustomerTickets.map((t) => (
                        <tr
                          key={t.id}
                          onClick={() => {
                            setSelectedCustomerId(null);
                            onSelectTicket(t.id);
                          }}
                          className="hover:bg-blue-50/40 cursor-pointer transition-colors"
                        >
                          <td className="py-2.5 px-3 font-mono font-bold text-blue-600">{t.id}</td>
                          <td className="py-2.5 px-3 font-medium text-slate-900 truncate max-w-xs">{t.subject}</td>
                          <td className="py-2.5 px-3">
                            <PriorityBadge priority={t.priority} />
                          </td>
                          <td className="py-2.5 px-3">
                            <StatusBadge status={t.status} />
                          </td>
                          <td className="py-2.5 px-3 text-slate-600">{new Date(t.dueDate).toLocaleDateString()}</td>
                          <td className="py-2.5 px-3 text-right">
                            <ExternalLink className="w-3.5 h-3.5 text-slate-400 hover:text-blue-600 inline" />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedCustomerId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCustomer ? 'Edit Customer Account' : 'Create New Customer Account'}
        subtitle="Salesforce Account & Contact record definition"
        maxWidth="md"
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs font-medium text-rose-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Full Name <span className="text-rose-500">*</span>
            </label>
            <input
              id="input-customer-fullname"
              type="text"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              placeholder="e.g., Sarah Connor"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Company / Account Name <span className="text-rose-500">*</span>
            </label>
            <input
              id="input-customer-company"
              type="text"
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              placeholder="e.g., Cyberdyne Systems"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Email Address <span className="text-rose-500">*</span>
              </label>
              <input
                id="input-customer-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="sarah@cyberdyne.io"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Phone Number
              </label>
              <input
                id="input-customer-phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+1 (555) 019-2834"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Account Status
            </label>
            <select
              id="select-customer-status"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              id="btn-save-customer"
              type="submit"
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              {editingCustomer ? 'Save Changes' : 'Create Customer'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Delete Customer Account"
        message={`Are you sure you want to delete ${customerToDelete?.fullName}? Note: Salesforce validation rules block deletion if the account has active support cases.`}
        confirmText="Delete Account"
        confirmVariant="danger"
      />
    </div>
  );
}
