import React from 'react';
import { Modal } from './Modal';
import { BookOpen, Layers, GitFork, ShieldCheck, Zap, BarChart2, Users, Cpu } from 'lucide-react';

interface SalesforceConceptsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SalesforceConceptsModal({ isOpen, onClose }: SalesforceConceptsModalProps) {
  const mappings = [
    {
      icon: <Layers className="w-5 h-5 text-blue-600" />,
      feature: 'Customer Entity',
      concept: 'Account & Contact Standard Objects',
      description: 'Stores business client details, industry, and contact coordinates. Represents the account hierarchy in Salesforce Service Cloud.',
    },
    {
      icon: <Layers className="w-5 h-5 text-indigo-600" />,
      feature: 'Ticket Entity',
      concept: 'Case Standard Object',
      description: 'The core transactional support record with Subject, Description, Priority, Status, SLA Due Date, and Resolution Notes.',
    },
    {
      icon: <Users className="w-5 h-5 text-violet-600" />,
      feature: 'Support Agent Entity',
      concept: 'User & Service Resource (Omni-Channel)',
      description: 'Support personnel categorized with Departments, Skill certifications, and live capacity/workload limits.',
    },
    {
      icon: <GitFork className="w-5 h-5 text-teal-600" />,
      feature: 'Object Relationships',
      concept: 'Lookup & Master-Detail Relationships',
      description: 'Ticket contains Lookup references to Customer (Account), Assigned Agent (Owner/User), and Category (Custom Picklist/Object).',
    },
    {
      icon: <Zap className="w-5 h-5 text-amber-600" />,
      feature: 'Ticket Assignment Automation',
      concept: 'Case Assignment Rules & Salesforce Flow',
      description: 'Automatically analyzes category skill and agent availability to route cases to the agent with the lowest active ticket workload.',
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-rose-600" />,
      feature: 'Status Transitions & Validation',
      concept: 'Support Process, Path & Validation Rules',
      description: 'Enforces proper lifecycle flow (New -> Open -> In Progress -> Resolved -> Closed) and blocks resolution without mandatory resolution notes.',
    },
    {
      icon: <BarChart2 className="w-5 h-5 text-emerald-600" />,
      feature: 'Dashboards & Reports',
      concept: 'Salesforce Reports & Dashboards',
      description: 'Real-time summary matrices, KPI cards, SLA compliance metrics, and agent workload distribution reports with CSV export.',
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-purple-600" />,
      feature: 'Role-Based Access Control',
      concept: 'Profiles, Roles & Permission Sets',
      description: 'Admin, Support Manager, and Support Agent roles with tailored permissions for case management and assignment.',
    },
    {
      icon: <Cpu className="w-5 h-5 text-sky-600" />,
      feature: 'AI Ticket Assistant',
      concept: 'Salesforce Einstein Service AI',
      description: 'Augments support agents with automated summaries, category/priority recommendations, and drafted responses.',
    },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Salesforce CRM Concept Architecture Guide"
      subtitle="How ServiceDesk implements core Salesforce Service Cloud principles"
      maxWidth="xl"
    >
      <div className="space-y-6">
        <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-lg text-sm text-blue-900 flex items-start gap-3">
          <BookOpen className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
          <p>
            <strong>Portfolio Note:</strong> This application is custom-built to demonstrate practical understanding of
            Salesforce CRM architecture. Each module maps directly to Salesforce Admin and Developer competencies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {mappings.map((item, index) => (
            <div
              key={index}
              className="p-4 rounded-lg border border-slate-200 bg-white hover:border-blue-300 hover:shadow-xs transition-all space-y-2"
            >
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-md bg-slate-50 border border-slate-100">{item.icon}</div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">{item.feature}</h4>
                  <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100">
                    Salesforce: {item.concept}
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pt-1">{item.description}</p>
            </div>
          ))}
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors shadow-xs"
          >
            Got it, continue exploring
          </button>
        </div>
      </div>
    </Modal>
  );
}
