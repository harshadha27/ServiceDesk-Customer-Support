import React from 'react';
import { TicketPriority, TicketStatus, SLAStatus, CustomerStatus, AgentAvailability } from '../../types';
import { AlertCircle, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';

export function StatusBadge({ status }: { status: TicketStatus }) {
  const styles: Record<TicketStatus, string> = {
    New: 'bg-blue-50 text-blue-700 border-blue-200 ring-1 ring-blue-500/10',
    Open: 'bg-indigo-50 text-indigo-700 border-indigo-200 ring-1 ring-indigo-500/10',
    'In Progress': 'bg-amber-50 text-amber-700 border-amber-200 ring-1 ring-amber-500/10',
    'Waiting for Customer': 'bg-purple-50 text-purple-700 border-purple-200 ring-1 ring-purple-500/10',
    Resolved: 'bg-emerald-50 text-emerald-700 border-emerald-200 ring-1 ring-emerald-500/10',
    Closed: 'bg-slate-100 text-slate-700 border-slate-200 ring-1 ring-slate-500/10',
  };

  return (
    <span
      id={`badge-status-${status.toLowerCase().replace(/\s+/g, '-')}`}
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${styles[status] || 'bg-gray-100 text-gray-800'}`}
    >
      <span className="w-1.5 h-1.5 rounded-full mr-1.5 bg-current opacity-70" />
      {status}
    </span>
  );
}

export function PriorityBadge({ priority, size = 'sm' }: { priority: TicketPriority; size?: 'sm' | 'md' }) {
  const isLarge = size === 'md';
  const styles: Record<TicketPriority, { bg: string; icon: React.ReactNode }> = {
    Critical: {
      bg: 'bg-rose-50 text-rose-700 border-rose-200 ring-1 ring-rose-500/20 font-semibold',
      icon: <AlertCircle className={`${isLarge ? 'w-4 h-4' : 'w-3 h-3'} mr-1 text-rose-600 animate-pulse`} />,
    },
    High: {
      bg: 'bg-orange-50 text-orange-700 border-orange-200 ring-1 ring-orange-500/10 font-medium',
      icon: <AlertTriangle className={`${isLarge ? 'w-4 h-4' : 'w-3 h-3'} mr-1 text-orange-600`} />,
    },
    Medium: {
      bg: 'bg-amber-50 text-amber-700 border-amber-200 ring-1 ring-amber-500/10 font-medium',
      icon: <Clock className={`${isLarge ? 'w-4 h-4' : 'w-3 h-3'} mr-1 text-amber-600`} />,
    },
    Low: {
      bg: 'bg-slate-50 text-slate-600 border-slate-200 ring-1 ring-slate-400/10 font-medium',
      icon: <CheckCircle2 className={`${isLarge ? 'w-4 h-4' : 'w-3 h-3'} mr-1 text-slate-500`} />,
    },
  };

  const current = styles[priority] || styles.Medium;

  return (
    <span
      id={`badge-priority-${priority.toLowerCase()}`}
      className={`inline-flex items-center ${isLarge ? 'px-3 py-1 text-sm' : 'px-2 py-0.5 text-xs'} rounded-md border whitespace-nowrap ${current.bg}`}
    >
      {current.icon}
      {priority}
    </span>
  );
}

export function SlaBadge({ sla }: { sla: SLAStatus }) {
  const styles: Record<SLAStatus['state'], string> = {
    'On Track': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'Due Soon': 'bg-amber-50 text-amber-700 border-amber-200 ring-1 ring-amber-400/30',
    Overdue: 'bg-red-50 text-red-700 border-red-200 font-semibold ring-1 ring-red-500/20',
    Resolved: 'bg-slate-50 text-slate-600 border-slate-200',
  };

  return (
    <span
      id={`badge-sla-${sla.state.toLowerCase().replace(/\s+/g, '-')}`}
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${styles[sla.state]}`}
      title={sla.state === 'Resolved' ? 'Resolved within SLA' : `${sla.hoursRemaining}h remaining (${sla.percentageUsed}% time elapsed)`}
    >
      <Clock className="w-3 h-3 mr-1 opacity-70" />
      {sla.state}
      {sla.state !== 'Resolved' && (
        <span className="ml-1 text-[10px] opacity-80">
          ({sla.hoursRemaining > 0 ? `${sla.hoursRemaining}h` : 'Expired'})
        </span>
      )}
    </span>
  );
}

export function CustomerStatusBadge({ status }: { status: CustomerStatus }) {
  return (
    <span
      id={`badge-cust-${status.toLowerCase()}`}
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${
        status === 'Active'
          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
          : 'bg-slate-100 text-slate-600 border-slate-200'
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${status === 'Active' ? 'bg-emerald-500' : 'bg-slate-400'}`} />
      {status}
    </span>
  );
}

export function AgentAvailabilityBadge({ availability }: { availability: AgentAvailability }) {
  const styles: Record<AgentAvailability, { color: string; dot: string }> = {
    Available: { color: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
    Busy: { color: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' },
    Offline: { color: 'bg-slate-100 text-slate-600 border-slate-200', dot: 'bg-slate-400' },
  };

  const cur = styles[availability] || styles.Offline;

  return (
    <span
      id={`badge-agent-${availability.toLowerCase()}`}
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${cur.color}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${cur.dot}`} />
      {availability}
    </span>
  );
}
