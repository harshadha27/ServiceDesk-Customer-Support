import React, { useMemo } from 'react';
import { Ticket, Agent, Customer, SLAStatus } from '../../types';
import { calculateSlaStatus } from '../../services/automationService';
import {
  LifeBuoy,
  Clock,
  CheckCircle,
  AlertTriangle,
  Users,
  AlertOctagon,
  Flame,
  ArrowRight,
  TrendingUp,
  Activity,
} from 'lucide-react';

interface DashboardProps {
  tickets: Ticket[];
  agents: Agent[];
  customers: Customer[];
  onSelectTicket: (ticketId: string) => void;
  onNavigateToTicketsWithFilter: (filter: { status?: string; priority?: string; overdueOnly?: boolean }) => void;
}

export function Dashboard({
  tickets,
  agents,
  customers,
  onSelectTicket,
  onNavigateToTicketsWithFilter,
}: DashboardProps) {
  // Calculated Metrics from live data (No hardcoding)
  const stats = useMemo(() => {
    const total = tickets.length;
    const open = tickets.filter((t) => t.status === 'Open' || t.status === 'New').length;
    const inProgress = tickets.filter((t) => t.status === 'In Progress' || t.status === 'Waiting for Customer').length;
    const resolved = tickets.filter((t) => t.status === 'Resolved').length;
    const closed = tickets.filter((t) => t.status === 'Closed').length;
    const critical = tickets.filter((t) => t.priority === 'Critical' && t.status !== 'Closed' && t.status !== 'Resolved').length;

    let overdueCount = 0;
    tickets.forEach((t) => {
      const sla = calculateSlaStatus(t);
      if (sla.state === 'Overdue') {
        overdueCount++;
      }
    });

    const availableAgents = agents.filter((a) => a.availability === 'Available').length;

    return {
      total,
      open,
      inProgress,
      resolved,
      closed,
      critical,
      overdue: overdueCount,
      availableAgents,
    };
  }, [tickets, agents]);

  // Chart 1: Tickets by Status
  const statusData = useMemo(() => {
    const counts: Record<string, number> = {
      New: 0,
      Open: 0,
      'In Progress': 0,
      'Waiting for Customer': 0,
      Resolved: 0,
      Closed: 0,
    };
    tickets.forEach((t) => {
      counts[t.status] = (counts[t.status] || 0) + 1;
    });
    return counts;
  }, [tickets]);

  // Chart 2: Tickets by Priority
  const priorityData = useMemo(() => {
    const counts = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    tickets.forEach((t) => {
      counts[t.priority] = (counts[t.priority] || 0) + 1;
    });
    return counts;
  }, [tickets]);

  // Chart 3: Tickets by Category
  const categoryData = useMemo(() => {
    const counts: Record<string, number> = {};
    tickets.forEach((t) => {
      counts[t.category] = (counts[t.category] || 0) + 1;
    });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  }, [tickets]);

  // Chart 4: Tickets by Agent (Active Workload)
  const agentWorkloadData = useMemo(() => {
    return agents.map((agent) => {
      const assigned = tickets.filter((t) => t.assignedAgentId === agent.id);
      const active = assigned.filter((t) => t.status !== 'Resolved' && t.status !== 'Closed').length;
      const completed = assigned.filter((t) => t.status === 'Resolved' || t.status === 'Closed').length;
      return {
        id: agent.id,
        name: agent.fullName,
        active,
        completed,
        total: assigned.length,
      };
    });
  }, [agents, tickets]);

  // SLA Compliance Metric
  const slaCompliance = useMemo(() => {
    const closedOrResolved = tickets.filter((t) => t.status === 'Resolved' || t.status === 'Closed');
    if (closedOrResolved.length === 0) return 100;
    let metSla = 0;
    closedOrResolved.forEach((t) => {
      if (t.resolutionDate && new Date(t.resolutionDate) <= new Date(t.dueDate)) {
        metSla++;
      } else if (!t.resolutionDate) {
        metSla++;
      }
    });
    return Math.round((metSla / closedOrResolved.length) * 100);
  }, [tickets]);

  // Critical / Overdue Urgent Queue
  const urgentTickets = useMemo(() => {
    return tickets
      .filter((t) => {
        const sla = calculateSlaStatus(t);
        return (t.priority === 'Critical' || sla.state === 'Overdue') && t.status !== 'Closed' && t.status !== 'Resolved';
      })
      .slice(0, 5);
  }, [tickets]);

  return (
    <div id="dashboard-view" className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">ServiceDesk CRM Operations Dashboard</h1>
            <span className="bg-blue-50 text-blue-700 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-blue-200">
              Live Metrics
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Real-time operational visibility into customer cases, SLA compliance, agent workloads, and resolution trends.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-600 bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
          <Activity className="w-4 h-4 text-emerald-500 animate-pulse" />
          <span>SLA Benchmark Compliance: <strong>{slaCompliance}%</strong></span>
        </div>
      </div>

      {/* 8 Primary Salesforce KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Total Tickets */}
        <div
          id="kpi-total-tickets"
          onClick={() => onNavigateToTicketsWithFilter({})}
          className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-blue-400 hover:shadow-sm cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Tickets</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600 group-hover:scale-110 transition-transform">
              <LifeBuoy className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{stats.total}</p>
          <p className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>All recorded cases</span>
            <ArrowRight className="w-3 h-3 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Open Tickets */}
        <div
          id="kpi-open-tickets"
          onClick={() => onNavigateToTicketsWithFilter({ status: 'Open' })}
          className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-indigo-400 hover:shadow-sm cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Open Tickets</span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 group-hover:scale-110 transition-transform">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-indigo-700 mt-2">{stats.open}</p>
          <p className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>New & Unassigned cases</span>
            <ArrowRight className="w-3 h-3 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* In Progress */}
        <div
          id="kpi-in-progress"
          onClick={() => onNavigateToTicketsWithFilter({ status: 'In Progress' })}
          className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-sm cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">In Progress</span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-600 group-hover:scale-110 transition-transform">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-amber-700 mt-2">{stats.inProgress}</p>
          <p className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Active investigation</span>
            <ArrowRight className="w-3 h-3 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Resolved */}
        <div
          id="kpi-resolved"
          onClick={() => onNavigateToTicketsWithFilter({ status: 'Resolved' })}
          className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-emerald-400 hover:shadow-sm cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Resolved</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 group-hover:scale-110 transition-transform">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-emerald-700 mt-2">{stats.resolved}</p>
          <p className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Pending customer signoff</span>
            <ArrowRight className="w-3 h-3 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Closed */}
        <div
          id="kpi-closed"
          onClick={() => onNavigateToTicketsWithFilter({ status: 'Closed' })}
          className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-slate-400 hover:shadow-sm cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Closed</span>
            <div className="p-2 rounded-lg bg-slate-100 text-slate-700 group-hover:scale-110 transition-transform">
              <CheckCircle className="w-4 h-4 text-slate-500" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-700 mt-2">{stats.closed}</p>
          <p className="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>Archived & Completed</span>
            <ArrowRight className="w-3 h-3 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Critical Tickets */}
        <div
          id="kpi-critical-tickets"
          onClick={() => onNavigateToTicketsWithFilter({ priority: 'Critical' })}
          className={`p-5 bg-white rounded-xl border shadow-xs hover:shadow-sm cursor-pointer transition-all group ${
            stats.critical > 0 ? 'border-rose-300 bg-rose-50/20' : 'border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-700 uppercase tracking-wider flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-rose-600" />
              Critical
            </span>
            <div className="p-2 rounded-lg bg-rose-100 text-rose-700 group-hover:scale-110 transition-transform">
              <AlertOctagon className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-rose-700 mt-2">{stats.critical}</p>
          <p className="text-xs text-rose-600 mt-1 flex items-center justify-between">
            <span>Requires 4h SLA handling</span>
            <ArrowRight className="w-3 h-3 text-rose-500 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Overdue Tickets */}
        <div
          id="kpi-overdue-tickets"
          onClick={() => onNavigateToTicketsWithFilter({ overdueOnly: true })}
          className={`p-5 bg-white rounded-xl border shadow-xs hover:shadow-sm cursor-pointer transition-all group ${
            stats.overdue > 0 ? 'border-red-300 bg-red-50/20' : 'border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-red-700 uppercase tracking-wider flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
              Overdue
            </span>
            <div className="p-2 rounded-lg bg-red-100 text-red-700 group-hover:scale-110 transition-transform">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-red-700 mt-2">{stats.overdue}</p>
          <p className="text-xs text-red-600 mt-1 flex items-center justify-between">
            <span>SLA deadline breached</span>
            <ArrowRight className="w-3 h-3 text-red-500 group-hover:translate-x-1 transition-transform" />
          </p>
        </div>

        {/* Available Agents */}
        <div
          id="kpi-available-agents"
          className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Available Agents</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-emerald-700 mt-2">
            {stats.availableAgents} <span className="text-sm font-normal text-slate-500">/ {agents.length}</span>
          </p>
          <p className="text-xs text-slate-500 mt-1">Ready for case routing</p>
        </div>
      </div>

      {/* Urgent Attention Queue (if any critical or overdue tickets exist) */}
      {urgentTickets.length > 0 && (
        <div className="bg-rose-50/60 border border-rose-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-rose-600 animate-pulse" />
              <h3 className="text-sm font-bold text-rose-900">Urgent Attention Queue (Critical or Overdue)</h3>
            </div>
            <span className="text-xs font-medium text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full">
              {urgentTickets.length} Actionable Items
            </span>
          </div>
          <div className="divide-y divide-rose-200/60 bg-white rounded-lg border border-rose-200 overflow-hidden">
            {urgentTickets.map((t) => {
              const sla = calculateSlaStatus(t);
              return (
                <div
                  key={t.id}
                  onClick={() => onSelectTicket(t.id)}
                  className="p-3.5 flex items-center justify-between hover:bg-rose-50/40 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-bold text-slate-700">{t.id}</span>
                    <span className="text-sm font-semibold text-slate-900 truncate max-w-md">{t.subject}</span>
                    <span className="text-xs text-slate-500 hidden md:inline">({t.customerName})</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      sla.state === 'Overdue' ? 'bg-red-100 text-red-700 font-bold' : 'bg-rose-100 text-rose-700'
                    }`}>
                      {sla.state === 'Overdue' ? 'SLA Expired' : 'Critical Priority'}
                    </span>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Primary Visual Charts Grid (Calculated dynamically) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Tickets by Status */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-slate-900">Tickets by Status</h3>
            <span className="text-xs text-slate-500">Live Distribution</span>
          </div>
          <div className="space-y-3">
            {Object.entries(statusData).map(([statusName, count]) => {
              const pct = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
              const colorMap: Record<string, string> = {
                New: 'bg-blue-500',
                Open: 'bg-indigo-500',
                'In Progress': 'bg-amber-500',
                'Waiting for Customer': 'bg-purple-500',
                Resolved: 'bg-emerald-500',
                Closed: 'bg-slate-400',
              };
              return (
                <div key={statusName} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-700">{statusName}</span>
                    <span className="text-slate-500 font-mono">
                      {count} ({pct}%)
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${colorMap[statusName] || 'bg-blue-500'}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 2: Tickets by Priority */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-slate-900">Tickets by Priority</h3>
            <span className="text-xs text-slate-500">Severity Breakdown</span>
          </div>
          <div className="grid grid-cols-2 gap-4 pt-2">
            {[
              { label: 'Critical', count: priorityData.Critical, color: 'bg-rose-500', border: 'border-rose-200', bg: 'bg-rose-50', text: 'text-rose-700' },
              { label: 'High', count: priorityData.High, color: 'bg-orange-500', border: 'border-orange-200', bg: 'bg-orange-50', text: 'text-orange-700' },
              { label: 'Medium', count: priorityData.Medium, color: 'bg-amber-500', border: 'border-amber-200', bg: 'bg-amber-50', text: 'text-amber-700' },
              { label: 'Low', count: priorityData.Low, color: 'bg-slate-400', border: 'border-slate-200', bg: 'bg-slate-50', text: 'text-slate-700' },
            ].map((p) => {
              const pct = stats.total > 0 ? Math.round((p.count / stats.total) * 100) : 0;
              return (
                <div key={p.label} className={`p-4 rounded-xl border ${p.border} ${p.bg} flex flex-col justify-between`}>
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold uppercase tracking-wider ${p.text}`}>{p.label}</span>
                    <span className="text-xs font-mono text-slate-500">{pct}%</span>
                  </div>
                  <p className={`text-2xl font-bold mt-2 ${p.text}`}>{p.count}</p>
                  <div className="w-full h-1.5 bg-slate-200 rounded-full mt-3 overflow-hidden">
                    <div className={`h-full ${p.color}`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 3: Tickets by Category */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-slate-900">Tickets by Category</h3>
            <span className="text-xs text-slate-500">Case Taxonomy</span>
          </div>
          <div className="space-y-3">
            {categoryData.map(([catName, count]) => {
              const pct = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
              return (
                <div key={catName} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-700">{catName}</span>
                    <span className="text-slate-500 font-mono">
                      {count} ({pct}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 4: Agent Workload & Capacity */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-slate-900">Support Agent Capacity & Workload</h3>
            <span className="text-xs text-slate-500">Active vs Resolved Cases</span>
          </div>
          <div className="space-y-3.5">
            {agentWorkloadData.map((agent) => {
              return (
                <div key={agent.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-semibold text-slate-900">{agent.name}</span>
                    <div className="flex items-center gap-3 font-mono">
                      <span className="text-amber-700 font-medium">Active: {agent.active}</span>
                      <span className="text-emerald-700 font-medium">Resolved: {agent.completed}</span>
                    </div>
                  </div>
                  <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden flex">
                    <div
                      className="bg-amber-500 h-full"
                      style={{ width: `${agent.total > 0 ? (agent.active / agent.total) * 100 : 0}%` }}
                      title={`Active: ${agent.active}`}
                    />
                    <div
                      className="bg-emerald-500 h-full"
                      style={{ width: `${agent.total > 0 ? (agent.completed / agent.total) * 100 : 0}%` }}
                      title={`Resolved: ${agent.completed}`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
