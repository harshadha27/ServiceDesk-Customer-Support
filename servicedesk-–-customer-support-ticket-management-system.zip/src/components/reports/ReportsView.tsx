import React, { useState, useMemo } from 'react';
import { Ticket, Agent, Customer, TicketCategory } from '../../types';
import { calculateSlaStatus } from '../../services/automationService';
import {
  BarChart3,
  Download,
  Clock,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  FileSpreadsheet,
  Users,
  Award,
} from 'lucide-react';

interface ReportsViewProps {
  tickets: Ticket[];
  agents: Agent[];
  customers: Customer[];
  categories: TicketCategory[];
}

export function ReportsView({ tickets, agents, customers, categories }: ReportsViewProps) {
  const [activeReportTab, setActiveReportTab] = useState<'sla' | 'agent' | 'category'>('sla');

  // SLA Report Calculations
  const slaMetrics = useMemo(() => {
    const closedOrResolved = tickets.filter((t) => t.status === 'Resolved' || t.status === 'Closed');
    let resolvedWithinSLA = 0;
    let totalResolutionHours = 0;
    let resolutionCount = 0;

    closedOrResolved.forEach((t) => {
      if (t.resolutionDate) {
        resolutionCount++;
        const created = new Date(t.createdDate).getTime();
        const resolved = new Date(t.resolutionDate).getTime();
        const due = new Date(t.dueDate).getTime();
        const hoursTaken = Math.max(1, Math.round((resolved - created) / (1000 * 60 * 60)));
        totalResolutionHours += hoursTaken;

        if (resolved <= due) {
          resolvedWithinSLA++;
        }
      } else {
        resolvedWithinSLA++;
      }
    });

    const complianceRate = closedOrResolved.length > 0 ? Math.round((resolvedWithinSLA / closedOrResolved.length) * 100) : 100;
    const avgResolutionTimeHours = resolutionCount > 0 ? Math.round(totalResolutionHours / resolutionCount) : 12;

    const overdueActiveTickets = tickets.filter((t) => {
      const s = calculateSlaStatus(t);
      return s.state === 'Overdue';
    });

    return {
      totalClosed: closedOrResolved.length,
      complianceRate,
      avgResolutionTimeHours,
      overdueActiveCount: overdueActiveTickets.length,
      overdueTickets: overdueActiveTickets,
    };
  }, [tickets]);

  // Agent Performance Report
  const agentPerformance = useMemo(() => {
    return agents.map((agent) => {
      const assigned = tickets.filter((t) => t.assignedAgentId === agent.id);
      const active = assigned.filter((t) => t.status !== 'Resolved' && t.status !== 'Closed').length;
      const completed = assigned.filter((t) => t.status === 'Resolved' || t.status === 'Closed').length;
      const rate = assigned.length > 0 ? Math.round((completed / assigned.length) * 100) : 0;

      return {
        id: agent.id,
        name: agent.fullName,
        department: agent.department,
        availability: agent.availability,
        totalAssigned: assigned.length,
        active,
        completed,
        resolutionRate: rate,
      };
    });
  }, [agents, tickets]);

  // Category Matrix
  const categoryMatrix = useMemo(() => {
    return categories.map((cat) => {
      const match = tickets.filter((t) => t.category === cat.name);
      const critical = match.filter((t) => t.priority === 'Critical').length;
      const high = match.filter((t) => t.priority === 'High').length;
      const completed = match.filter((t) => t.status === 'Resolved' || t.status === 'Closed').length;
      const rate = match.length > 0 ? Math.round((completed / match.length) * 100) : 0;

      return {
        id: cat.id,
        name: cat.name,
        total: match.length,
        critical,
        high,
        completed,
        rate,
      };
    });
  }, [categories, tickets]);

  // Export CSV for Agent Matrix
  const exportAgentReportCSV = () => {
    const headers = ['Agent Name', 'Department', 'Availability', 'Total Assigned', 'Active Cases', 'Completed Cases', 'Resolution Rate (%)'];
    const rows = agentPerformance.map((a) => [
      `"${a.name}"`,
      `"${a.department}"`,
      a.availability,
      a.totalAssigned,
      a.active,
      a.completed,
      `${a.resolutionRate}%`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const link = document.createElement('a');
    link.setAttribute('href', encodeURI(csvContent));
    link.setAttribute('download', `ServiceDesk_Agent_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="reports-view" className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Reports & Service Analytics</h1>
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              Salesforce Reports
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Analyze operational metrics, service level agreement (SLA) fulfillment, and support representative productivity.
          </p>
        </div>

        <button
          id="btn-export-agent-report"
          type="button"
          onClick={exportAgentReportCSV}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          <span>Export Agent Report (CSV)</span>
        </button>
      </div>

      {/* Report Tabs */}
      <div className="border-b border-slate-200 bg-white rounded-t-xl px-4 flex gap-6 text-sm font-semibold text-slate-600 shadow-xs">
        <button
          id="tab-report-sla"
          type="button"
          onClick={() => setActiveReportTab('sla')}
          className={`py-3.5 border-b-2 flex items-center gap-2 transition-colors ${
            activeReportTab === 'sla' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>SLA Compliance Report</span>
        </button>

        <button
          id="tab-report-agents"
          type="button"
          onClick={() => setActiveReportTab('agent')}
          className={`py-3.5 border-b-2 flex items-center gap-2 transition-colors ${
            activeReportTab === 'agent' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Agent Performance Matrix</span>
        </button>

        <button
          id="tab-report-categories"
          type="button"
          onClick={() => setActiveReportTab('category')}
          className={`py-3.5 border-b-2 flex items-center gap-2 transition-colors ${
            activeReportTab === 'category' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Taxonomy Volume Matrix</span>
        </button>
      </div>

      {/* SLA Tab Content */}
      {activeReportTab === 'sla' && (
        <div className="space-y-6">
          {/* SLA Top KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">SLA Compliance Rate</span>
                <CheckCircle className="w-4 h-4 text-emerald-500" />
              </div>
              <p className="text-3xl font-bold text-emerald-700 mt-2">{slaMetrics.complianceRate}%</p>
              <p className="text-xs text-slate-500 mt-1">Resolved within targeted priority deadline</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Mean Time to Resolve (MTTR)</span>
                <Clock className="w-4 h-4 text-blue-500" />
              </div>
              <p className="text-3xl font-bold text-slate-900 mt-2">{slaMetrics.avgResolutionTimeHours} hrs</p>
              <p className="text-xs text-slate-500 mt-1">Average turnaround across all categories</p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Overdue Breaches</span>
                <AlertTriangle className="w-4 h-4 text-red-500" />
              </div>
              <p className="text-3xl font-bold text-red-700 mt-2">{slaMetrics.overdueActiveCount}</p>
              <p className="text-xs text-slate-500 mt-1">Tickets currently exceeding SLA window</p>
            </div>
          </div>

          {/* SLA Guidelines Explanation Box */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-slate-900">ServiceDesk Standard SLA Matrix</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg">
                <span className="font-bold text-rose-800 block">Critical: 4 Hours</span>
                <span className="text-rose-600 text-[11px]">System outages, critical security flaws</span>
              </div>
              <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                <span className="font-bold text-orange-800 block">High: 8 Hours</span>
                <span className="text-orange-600 text-[11px]">Core workflow degradation</span>
              </div>
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <span className="font-bold text-amber-800 block">Medium: 24 Hours</span>
                <span className="text-amber-600 text-[11px]">Non-blocking bugs, billing queries</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <span className="font-bold text-slate-800 block">Low: 48 Hours</span>
                <span className="text-slate-600 text-[11px]">Feature requests & documentation inquiries</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Agent Performance Tab */}
      {activeReportTab === 'agent' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <th className="py-3 px-4">Agent Name</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Availability</th>
                <th className="py-3 px-4 text-center">Total Assigned</th>
                <th className="py-3 px-4 text-center">Active Cases</th>
                <th className="py-3 px-4 text-center">Resolved Cases</th>
                <th className="py-3 px-4 text-right">Resolution Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {agentPerformance.map((a) => (
                <tr key={a.id} className="hover:bg-slate-50/50">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{a.name}</td>
                  <td className="py-3.5 px-4 text-slate-600">{a.department}</td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${
                        a.availability === 'Available'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {a.availability}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-medium">{a.totalAssigned}</td>
                  <td className="py-3.5 px-4 text-center font-mono text-amber-700 font-bold">{a.active}</td>
                  <td className="py-3.5 px-4 text-center font-mono text-emerald-700 font-bold">{a.completed}</td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-blue-600">{a.resolutionRate}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Category Matrix Tab */}
      {activeReportTab === 'category' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <th className="py-3 px-4">Category Taxonomy</th>
                <th className="py-3 px-4 text-center">Total Volume</th>
                <th className="py-3 px-4 text-center">Critical Priority</th>
                <th className="py-3 px-4 text-center">High Priority</th>
                <th className="py-3 px-4 text-center">Resolved</th>
                <th className="py-3 px-4 text-right">Completion Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {categoryMatrix.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50/50">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{c.name}</td>
                  <td className="py-3.5 px-4 text-center font-mono font-medium">{c.total}</td>
                  <td className="py-3.5 px-4 text-center font-mono text-rose-700 font-bold">{c.critical}</td>
                  <td className="py-3.5 px-4 text-center font-mono text-orange-700 font-medium">{c.high}</td>
                  <td className="py-3.5 px-4 text-center font-mono text-emerald-700 font-bold">{c.completed}</td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-blue-600">{c.rate}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
