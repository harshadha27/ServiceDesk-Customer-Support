import React from 'react';
import { Search, Plus, Shield, User, Sparkles, BookOpen } from 'lucide-react';
import { UserRole } from '../../types';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (val: string) => void;
  activeRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onOpenCreateTicket: () => void;
  onOpenConcepts: () => void;
  criticalAlertCount: number;
}

export function Header({
  searchQuery,
  onSearchChange,
  activeRole,
  onRoleChange,
  onOpenCreateTicket,
  onOpenConcepts,
  criticalAlertCount,
}: HeaderProps) {
  const roles: UserRole[] = ['Admin', 'Support Manager', 'Support Agent'];

  const roleDescriptions: Record<UserRole, string> = {
    Admin: 'Full system access (CRUD records, automation config, system settings)',
    'Support Manager': 'Management access (Dashboard, all tickets, queue reassignments, reports)',
    'Support Agent': 'Agent workspace (Assigned tickets, status transitions, comments, resolution)',
  };

  return (
    <header
      id="app-header"
      className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between gap-4 sticky top-0 z-30 shadow-xs"
    >
      {/* Global Search Bar */}
      <div className="flex-1 max-w-xl relative">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="global-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search tickets by ID, subject, customer, agent, priority, category..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
          />
        </div>
      </div>

      {/* Action Controls & Role Switcher */}
      <div className="flex items-center gap-3">
        {/* Salesforce Concept Pill */}
        <button
          id="btn-header-salesforce-guide"
          type="button"
          onClick={onOpenConcepts}
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-colors"
          title="Learn how this CRM maps to Salesforce Service Cloud"
        >
          <BookOpen className="w-3.5 h-3.5 text-blue-600" />
          <span>Salesforce Guide</span>
        </button>

        {/* Role Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg border border-slate-200" title={roleDescriptions[activeRole]}>
          <Shield className="w-3.5 h-3.5 text-slate-500 ml-1.5 shrink-0" />
          <span className="text-xs font-semibold text-slate-500 hidden md:inline">Role:</span>
          <select
            id="role-selector"
            value={activeRole}
            onChange={(e) => onRoleChange(e.target.value as UserRole)}
            className="bg-transparent text-xs font-semibold text-slate-800 focus:outline-none cursor-pointer pr-1 py-0.5"
          >
            {roles.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>

        {/* Create Ticket Primary CTA */}
        <button
          id="btn-create-ticket-header"
          type="button"
          onClick={onOpenCreateTicket}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs shadow-blue-500/20 active:scale-98"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">New Ticket</span>
        </button>
      </div>
    </header>
  );
}
