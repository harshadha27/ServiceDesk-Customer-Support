import React from 'react';
import {
  LayoutDashboard,
  LifeBuoy,
  Users,
  UserCheck,
  Tag,
  BarChart3,
  Settings,
  HelpCircle,
  Headphones,
  RotateCcw,
} from 'lucide-react';
import { UserRole } from '../../types';

export type ActiveModule =
  | 'dashboard'
  | 'tickets'
  | 'customers'
  | 'agents'
  | 'categories'
  | 'reports'
  | 'settings';

interface SidebarProps {
  currentModule: ActiveModule;
  onNavigate: (module: ActiveModule) => void;
  openTicketsCount: number;
  criticalTicketsCount: number;
  activeRole: UserRole;
  onOpenConcepts: () => void;
  onResetData: () => void;
}

export function Sidebar({
  currentModule,
  onNavigate,
  openTicketsCount,
  criticalTicketsCount,
  activeRole,
  onOpenConcepts,
  onResetData,
}: SidebarProps) {
  const navItems: { id: ActiveModule; label: string; icon: React.ReactNode; badge?: number; badgeColor?: string; allowedRoles?: UserRole[] }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    {
      id: 'tickets',
      label: 'Tickets (Cases)',
      icon: <LifeBuoy className="w-4 h-4" />,
      badge: openTicketsCount,
      badgeColor: criticalTicketsCount > 0 ? 'bg-rose-500 text-white' : 'bg-blue-100 text-blue-700',
    },
    {
      id: 'customers',
      label: 'Customers (Accounts)',
      icon: <Users className="w-4 h-4" />,
    },
    {
      id: 'agents',
      label: 'Support Agents',
      icon: <UserCheck className="w-4 h-4" />,
      allowedRoles: ['Admin', 'Support Manager'],
    },
    {
      id: 'categories',
      label: 'Ticket Categories',
      icon: <Tag className="w-4 h-4" />,
      allowedRoles: ['Admin', 'Support Manager'],
    },
    {
      id: 'reports',
      label: 'Reports & Analytics',
      icon: <BarChart3 className="w-4 h-4" />,
      allowedRoles: ['Admin', 'Support Manager'],
    },
    {
      id: 'settings',
      label: 'Settings & Testing',
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  return (
    <aside
      id="app-sidebar"
      className="w-64 bg-slate-900 text-slate-300 flex flex-col h-screen border-r border-slate-800 shrink-0 select-none"
    >
      {/* Brand Header */}
      <div className="h-16 flex items-center px-5 border-b border-slate-800/80 bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white text-base tracking-tight">ServiceDesk</span>
              <span className="text-[10px] font-semibold uppercase tracking-wider bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded border border-blue-400/20">
                CRM
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate">Customer Support System</p>
          </div>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
            CRM Modules
          </p>
        </div>

        {navItems.map((item) => {
          const isAllowed = !item.allowedRoles || item.allowedRoles.includes(activeRole);
          const isActive = currentModule === item.id;

          if (!isAllowed) return null;

          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className={`text-[11px] px-2 py-0.5 rounded-full font-semibold ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Educational & Quick Action Footer */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/30 space-y-2">
        <button
          id="btn-salesforce-concepts"
          type="button"
          onClick={onOpenConcepts}
          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-blue-400 bg-blue-950/40 hover:bg-blue-900/40 border border-blue-800/40 rounded-lg transition-colors text-left"
        >
          <HelpCircle className="w-4 h-4 shrink-0 text-blue-400" />
          <div>
            <p className="font-semibold text-white">Salesforce Concepts</p>
            <p className="text-[10px] text-blue-300/80">View CRM architecture mapping</p>
          </div>
        </button>

        <button
          id="btn-reset-sample-data"
          type="button"
          onClick={onResetData}
          className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-md transition-colors"
          title="Reset database to 10 Customers, 5 Agents, and 20 Tickets"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sample Data</span>
        </button>
      </div>
    </aside>
  );
}
