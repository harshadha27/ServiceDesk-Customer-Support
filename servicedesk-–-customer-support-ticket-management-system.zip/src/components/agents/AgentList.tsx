import React, { useState, useMemo } from 'react';
import { Agent, Ticket, AgentAvailability } from '../../types';
import { AgentAvailabilityBadge, StatusBadge, PriorityBadge } from '../common/Badges';
import { Modal, ConfirmDialog } from '../common/Modal';
import {
  UserCheck,
  Plus,
  Search,
  Mail,
  Briefcase,
  Edit2,
  Trash2,
  Eye,
  LifeBuoy,
  AlertCircle,
  Award,
  ExternalLink,
} from 'lucide-react';

interface AgentListProps {
  agents: Agent[];
  tickets: Ticket[];
  onSelectTicket: (ticketId: string) => void;
  onCreateAgent: (agent: Omit<Agent, 'id' | 'activeTickets'>) => { success: boolean; error?: string };
  onUpdateAgent: (id: string, updates: Partial<Agent>) => { success: boolean; error?: string };
  onDeleteAgent: (id: string) => { success: boolean; error?: string };
}

export function AgentList({
  agents,
  tickets,
  onSelectTicket,
  onCreateAgent,
  onUpdateAgent,
  onDeleteAgent,
}: AgentListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);

  // Create / Edit modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    department: 'Technical Support',
    skillsInput: '',
    availability: 'Available' as AgentAvailability,
  });
  const [formError, setFormError] = useState<string | null>(null);

  // Delete dialog
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [agentToDelete, setAgentToDelete] = useState<Agent | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const getAgentSkills = (a: Agent): string[] => {
    if (Array.isArray(a.skills) && a.skills.length > 0) return a.skills;
    if (a.skill) return a.skill.split(',').map((s) => s.trim()).filter(Boolean);
    return [];
  };

  const filteredAgents = useMemo(() => {
    if (!searchTerm.trim()) return agents;
    const q = searchTerm.toLowerCase();
    return agents.filter(
      (a) =>
        a.fullName.toLowerCase().includes(q) ||
        a.email.toLowerCase().includes(q) ||
        a.department.toLowerCase().includes(q) ||
        getAgentSkills(a).some((s) => s.toLowerCase().includes(q))
    );
  }, [agents, searchTerm]);

  const activeAgent = useMemo(() => {
    return agents.find((a) => a.id === selectedAgentId) || null;
  }, [agents, selectedAgentId]);

  const activeAgentTickets = useMemo(() => {
    if (!activeAgent) return [];
    return tickets.filter((t) => t.assignedAgentId === activeAgent.id);
  }, [tickets, activeAgent]);

  const handleOpenCreate = () => {
    setEditingAgent(null);
    setFormData({
      fullName: '',
      email: '',
      department: 'Technical Support',
      skillsInput: 'Technical Issue, Bug Triage',
      availability: 'Available',
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (agent: Agent) => {
    setEditingAgent(agent);
    setFormData({
      fullName: agent.fullName,
      email: agent.email,
      department: agent.department,
      skillsInput: getAgentSkills(agent).join(', '),
      availability: agent.availability,
    });
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.fullName.trim()) {
      setFormError('Validation Rule: Full Name is required.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setFormError('Validation Rule: Valid email format is required.');
      return;
    }
    if (!formData.department.trim()) {
      setFormError('Validation Rule: Department is required.');
      return;
    }

    const skills = formData.skillsInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    if (editingAgent) {
      const res = onUpdateAgent(editingAgent.id, {
        fullName: formData.fullName,
        email: formData.email,
        department: formData.department,
        skill: skills[0] || 'General Support',
        skills,
        availability: formData.availability,
      });
      if (res.success) {
        setIsModalOpen(false);
      } else {
        setFormError(res.error || 'Failed to update agent');
      }
    } else {
      const res = onCreateAgent({
        fullName: formData.fullName,
        email: formData.email,
        department: formData.department,
        role: 'Support Agent',
        skill: skills[0] || 'General Support',
        skills,
        availability: formData.availability,
        createdDate: new Date().toISOString(),
      });
      if (res.success) {
        setIsModalOpen(false);
      } else {
        setFormError(res.error || 'Failed to create agent');
      }
    }
  };

  const handleConfirmDelete = () => {
    if (!agentToDelete) return;
    const res = onDeleteAgent(agentToDelete.id);
    if (!res.success) {
      setDeleteError(res.error || 'Cannot delete agent.');
    } else {
      setAgentToDelete(null);
      setDeleteConfirmOpen(false);
      if (selectedAgentId === agentToDelete.id) {
        setSelectedAgentId(null);
      }
    }
  };

  return (
    <div id="agents-view" className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Support Agents (Service Resources)</h1>
            <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full border border-slate-200">
              {agents.length} Agents
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Manage support personnel, certified technical skills, live availability, and real-time active ticket workloads.
          </p>
        </div>

        <button
          id="btn-create-agent"
          type="button"
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>New Agent</span>
        </button>
      </div>

      {deleteError && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs font-medium text-rose-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{deleteError}</span>
          </div>
          <button type="button" onClick={() => setDeleteError(null)} className="text-rose-600 hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Search Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between gap-4">
        <div className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="search-agent-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search agents by name, email, department, skills..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
        <span className="text-xs text-slate-500">
          Showing {filteredAgents.length} of {agents.length}
        </span>
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredAgents.map((a) => {
          const assignedTickets = tickets.filter((t) => t.assignedAgentId === a.id);
          const activeCount = assignedTickets.filter((t) => t.status !== 'Resolved' && t.status !== 'Closed').length;

          return (
            <div
              key={a.id}
              id={`agent-card-${a.id}`}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-blue-300 hover:shadow-sm transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">{a.fullName}</h3>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5 font-medium">
                      <Briefcase className="w-3 h-3 text-slate-400" />
                      <span>{a.department}</span>
                    </p>
                  </div>
                  <AgentAvailabilityBadge availability={a.availability} />
                </div>

                <div className="text-xs text-slate-600 pt-1">
                  <p className="flex items-center gap-2 truncate font-mono">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{a.email}</span>
                  </p>
                </div>

                {/* Skills Chips */}
                <div className="pt-1">
                  <span className="text-[11px] font-semibold text-slate-400 block mb-1">Skills:</span>
                  <div className="flex flex-wrap gap-1">
                    {getAgentSkills(a).map((skill: string, idx: number) => (
                      <span
                        key={idx}
                        className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-medium border border-slate-200"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Workload & Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <LifeBuoy className="w-4 h-4 text-amber-600" />
                  <span className="font-semibold text-slate-800">
                    Active Workload: <span className="text-amber-700">{activeCount} Cases</span>
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setSelectedAgentId(a.id)}
                    className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="View Agent Workload & Cases"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(a)}
                    className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="Edit Agent"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAgentToDelete(a);
                      setDeleteError(null);
                      setDeleteConfirmOpen(true);
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="Delete Agent"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Agent Detail Modal */}
      {activeAgent && (
        <Modal
          isOpen={!!activeAgent}
          onClose={() => setSelectedAgentId(null)}
          title={`Support Agent: ${activeAgent.fullName}`}
          subtitle="Salesforce Service Cloud Omni-Channel Workload & Cases"
          maxWidth="xl"
        >
          <div className="space-y-6">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="font-semibold text-slate-500 block">Department</span>
                <span className="font-bold text-slate-900 mt-0.5 block">{activeAgent.department}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Email</span>
                <span className="font-mono text-slate-800 mt-0.5 block">{activeAgent.email}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Availability</span>
                <div className="mt-0.5">
                  <AgentAvailabilityBadge availability={activeAgent.availability} />
                </div>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Active Tickets</span>
                <span className="font-bold text-amber-700 mt-0.5 block text-sm">
                  {activeAgentTickets.filter((t) => t.status !== 'Resolved' && t.status !== 'Closed').length} Cases
                </span>
              </div>
            </div>

            {/* Assigned Tickets */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <LifeBuoy className="w-4 h-4 text-blue-600" />
                  <span>Assigned Support Cases ({activeAgentTickets.length})</span>
                </h3>
                <span className="text-xs text-slate-500">Salesforce Case Queue</span>
              </div>

              {activeAgentTickets.length === 0 ? (
                <div className="p-8 text-center text-slate-500 border border-slate-200 rounded-xl bg-white">
                  No cases assigned to this agent.
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                        <th className="py-2.5 px-3">Case ID</th>
                        <th className="py-2.5 px-3">Subject</th>
                        <th className="py-2.5 px-3">Customer</th>
                        <th className="py-2.5 px-3">Priority</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3 text-right">View</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {activeAgentTickets.map((t) => (
                        <tr
                          key={t.id}
                          onClick={() => {
                            setSelectedAgentId(null);
                            onSelectTicket(t.id);
                          }}
                          className="hover:bg-blue-50/40 cursor-pointer transition-colors"
                        >
                          <td className="py-2.5 px-3 font-mono font-bold text-blue-600">{t.id}</td>
                          <td className="py-2.5 px-3 font-medium text-slate-900 truncate max-w-xs">{t.subject}</td>
                          <td className="py-2.5 px-3 text-slate-600">{t.customerName}</td>
                          <td className="py-2.5 px-3">
                            <PriorityBadge priority={t.priority} />
                          </td>
                          <td className="py-2.5 px-3">
                            <StatusBadge status={t.status} />
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <ExternalLink className="w-3.5 h-3.5 text-slate-400 hover:text-blue-600 inline" />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedAgentId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingAgent ? 'Edit Support Agent' : 'Create New Support Agent'}
        subtitle="Salesforce User / Omni-Channel Service Resource"
        maxWidth="md"
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs font-medium text-rose-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Full Name <span className="text-rose-500">*</span>
            </label>
            <input
              id="input-agent-fullname"
              type="text"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              placeholder="e.g., Jane Doe"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Email Address <span className="text-rose-500">*</span>
              </label>
              <input
                id="input-agent-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="jane@servicedesk.io"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Department <span className="text-rose-500">*</span>
              </label>
              <input
                id="input-agent-department"
                type="text"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                placeholder="e.g., Technical Support"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Certified Skills (comma separated)
            </label>
            <input
              id="input-agent-skills"
              type="text"
              value={formData.skillsInput}
              onChange={(e) => setFormData({ ...formData, skillsInput: e.target.value })}
              placeholder="Technical Issue, Billing, Login, API"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Case assignment rules match ticket categories to these skills.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Live Availability
            </label>
            <select
              id="select-agent-availability"
              value={formData.availability}
              onChange={(e) => setFormData({ ...formData, availability: e.target.value as any })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="Available">Available (Ready for routing)</option>
              <option value="Busy">Busy</option>
              <option value="Offline">Offline</option>
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              id="btn-save-agent"
              type="submit"
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              {editingAgent ? 'Save Changes' : 'Create Agent'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Delete Support Agent"
        message={`Are you sure you want to delete ${agentToDelete?.fullName}? Note: Salesforce validation rules block deletion if the agent has active assigned support cases.`}
        confirmText="Delete Agent"
        confirmVariant="danger"
      />
    </div>
  );
}
