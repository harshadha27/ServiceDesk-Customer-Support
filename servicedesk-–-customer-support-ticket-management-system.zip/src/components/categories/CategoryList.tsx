import React, { useState } from 'react';
import { TicketCategory, Ticket } from '../../types';
import { Modal, ConfirmDialog } from '../common/Modal';
import { Tag, Plus, Edit2, Trash2, LifeBuoy, AlertCircle, CheckCircle2 } from 'lucide-react';

interface CategoryListProps {
  categories: TicketCategory[];
  tickets: Ticket[];
  onCreateCategory: (cat: { name: string; description: string }) => { success: boolean; error?: string };
  onUpdateCategory: (id: string, updates: Partial<TicketCategory>) => { success: boolean; error?: string };
  onDeleteCategory: (id: string) => { success: boolean; error?: string };
}

export function CategoryList({
  categories,
  tickets,
  onCreateCategory,
  onUpdateCategory,
  onDeleteCategory,
}: CategoryListProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<TicketCategory | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [catToDelete, setCatToDelete] = useState<TicketCategory | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingCategory(null);
    setName('');
    setDescription('');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (cat: TicketCategory) => {
    setEditingCategory(cat);
    setName(cat.name);
    setDescription(cat.description);
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!name.trim()) {
      setFormError('Validation Rule: Category Name is required.');
      return;
    }

    if (editingCategory) {
      const res = onUpdateCategory(editingCategory.id, { name, description });
      if (res.success) {
        setIsModalOpen(false);
      } else {
        setFormError(res.error || 'Failed to update category');
      }
    } else {
      const res = onCreateCategory({ name, description });
      if (res.success) {
        setIsModalOpen(false);
      } else {
        setFormError(res.error || 'Failed to create category');
      }
    }
  };

  const handleConfirmDelete = () => {
    if (!catToDelete) return;
    const res = onDeleteCategory(catToDelete.id);
    if (!res.success) {
      setDeleteError(res.error || 'Cannot delete category');
    } else {
      setCatToDelete(null);
      setDeleteConfirmOpen(false);
    }
  };

  return (
    <div id="categories-view" className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Ticket Categories (Case Taxonomy)</h1>
            <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full border border-slate-200">
              {categories.length} Taxonomies
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Configure case classification picklists and taxonomy values used in automated skill-based assignment routing.
          </p>
        </div>

        <button
          id="btn-create-category"
          type="button"
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>New Category</span>
        </button>
      </div>

      {deleteError && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs font-medium text-rose-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{deleteError}</span>
          </div>
          <button type="button" onClick={() => setDeleteError(null)} className="text-rose-600 hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {categories.map((cat) => {
          const matchingTickets = tickets.filter((t) => t.category === cat.name);

          return (
            <div
              key={cat.id}
              id={`category-card-${cat.id}`}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-blue-300 hover:shadow-sm transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                      <Tag className="w-4 h-4" />
                    </div>
                    <h3 className="text-base font-bold text-slate-900">{cat.name}</h3>
                  </div>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed min-h-[36px]">{cat.description}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-slate-600 font-medium">
                  <LifeBuoy className="w-4 h-4 text-blue-600" />
                  <span>{matchingTickets.length} Associated Cases</span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(cat)}
                    className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="Edit Category"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCatToDelete(cat);
                      setDeleteError(null);
                      setDeleteConfirmOpen(true);
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-md transition-colors"
                    title="Delete Category"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCategory ? 'Edit Ticket Category' : 'Create New Ticket Category'}
        subtitle="Salesforce Case Category Picklist Value"
        maxWidth="md"
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs font-medium text-rose-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Category Name <span className="text-rose-500">*</span>
            </label>
            <input
              id="input-cat-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Billing & Invoicing"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Description
            </label>
            <textarea
              id="input-cat-description"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what inquiries fall under this taxonomy..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              id="btn-save-category"
              type="submit"
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              {editingCategory ? 'Save Changes' : 'Create Category'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Delete Ticket Category"
        message={`Are you sure you want to delete "${catToDelete?.name}"? Note: Salesforce validation rules prevent deletion of categories that have existing tickets.`}
        confirmText="Delete Category"
        confirmVariant="danger"
      />
    </div>
  );
}
