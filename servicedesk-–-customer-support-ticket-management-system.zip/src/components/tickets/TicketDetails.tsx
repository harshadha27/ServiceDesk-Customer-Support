import React, { useState, useEffect } from 'react';
import {
  Ticket,
  Agent,
  Customer,
  TicketCategory,
  TicketPriority,
  TicketStatus,
  TicketComment,
  TicketHistoryItem,
  AIAssistantResult,
  UserRole,
} from '../../types';
import { StatusBadge, PriorityBadge, SlaBadge } from '../common/Badges';
import { Modal } from '../common/Modal';
import { calculateSlaStatus, ALLOWED_TRANSITIONS } from '../../services/automationService';
import { requestAITicketAssistant } from '../../services/aiService';
import {
  ArrowLeft,
  CheckCircle,
  Clock,
  UserCheck,
  Tag,
  AlertTriangle,
  MessageSquare,
  History,
  Sparkles,
  Send,
  Lock,
  Calendar,
  AlertCircle,
  Edit3,
  RotateCcw,
  Check,
  Copy,
} from 'lucide-react';

interface TicketDetailsProps {
  ticket: Ticket;
  agents: Agent[];
  customers: Customer[];
  categories: TicketCategory[];
  comments: TicketComment[];
  history: TicketHistoryItem[];
  activeRole: UserRole;
  onBack: () => void;
  onNavigateToCustomer: (customerId: string) => void;
  onNavigateToAgent: (agentId: string) => void;
  onUpdateStatus: (ticketId: string, status: TicketStatus, notes?: string) => { success: boolean; error?: string };
  onUpdatePriority: (ticketId: string, priority: TicketPriority) => { success: boolean; error?: string };
  onReassignAgent: (ticketId: string, agentId: string | null) => { success: boolean; error?: string };
  onAddComment: (ticketId: string, comment: string, isInternal: boolean) => { success: boolean; error?: string };
  onApplyCategory?: (ticketId: string, category: string) => void;
}

export function TicketDetails({
  ticket,
  agents,
  customers,
  categories,
  comments,
  history,
  activeRole,
  onBack,
  onNavigateToCustomer,
  onNavigateToAgent,
  onUpdateStatus,
  onUpdatePriority,
  onReassignAgent,
  onAddComment,
}: TicketDetailsProps) {
  const [activeTab, setActiveTab] = useState<'details' | 'comments' | 'history' | 'ai'>('details');

  // Modals state
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [targetStatus, setTargetStatus] = useState<TicketStatus>('Open');
  const [resolutionNotes, setResolutionNotes] = useState(ticket.resolutionNotes || '');
  const [statusError, setStatusError] = useState<string | null>(null);

  const [priorityModalOpen, setPriorityModalOpen] = useState(false);
  const [targetPriority, setTargetPriority] = useState<TicketPriority>(ticket.priority);

  const [reassignModalOpen, setReassignModalOpen] = useState(false);
  const [targetAgentId, setTargetAgentId] = useState<string>(ticket.assignedAgentId || '');

  // Comments state
  const [newCommentText, setNewCommentText] = useState('');
  const [isInternalNote, setIsInternalNote] = useState(false);
  const [commentError, setCommentError] = useState<string | null>(null);

  // AI Assistant state
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<AIAssistantResult | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [copiedDraft, setCopiedDraft] = useState(false);

  const sla = calculateSlaStatus(ticket);
  const allowedTransitions = ALLOWED_TRANSITIONS[ticket.status] || [];

  const handleStatusSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusError(null);

    const res = onUpdateStatus(ticket.id, targetStatus, resolutionNotes);
    if (res.success) {
      setStatusModalOpen(false);
    } else {
      setStatusError(res.error || 'Failed to update status');
    }
  };

  const handlePrioritySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePriority(ticket.id, targetPriority);
    setPriorityModalOpen(false);
  };

  const handleReassignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onReassignAgent(ticket.id, targetAgentId ? targetAgentId : null);
    setReassignModalOpen(false);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCommentError(null);
    if (!newCommentText.trim()) {
      setCommentError('Please enter a comment.');
      return;
    }
    const authorName = activeRole === 'Admin' ? 'System Administrator' : activeRole === 'Support Manager' ? 'Support Manager' : 'Support Agent';
    const res = onAddComment(ticket.id, newCommentText, isInternalNote);
    if (res.success) {
      setNewCommentText('');
    } else {
      setCommentError(res.error || 'Failed to submit comment');
    }
  };

  // Run AI Assistant
  const handleRunAiAnalysis = async () => {
    setAiLoading(true);
    setAiError(null);
    try {
      const result = await requestAITicketAssistant({
        subject: ticket.subject,
        description: ticket.description,
        customerName: ticket.customerName,
        currentCategory: ticket.category,
        currentPriority: ticket.priority,
      });
      setAiResult(result);
    } catch (err: any) {
      setAiError(err?.message || 'Failed to analyze ticket with AI');
    } finally {
      setAiLoading(false);
    }
  };

  // Salesforce Path lifecycle states
  const lifecycleSteps: TicketStatus[] = [
    'New',
    'Open',
    'In Progress',
    'Waiting for Customer',
    'Resolved',
    'Closed',
  ];

  const currentStepIndex = lifecycleSteps.indexOf(ticket.status);

  return (
    <div id="ticket-details-view" className="space-y-6 pb-16">
      {/* Top Navigation & Record Header */}
      <div className="flex items-center justify-between">
        <button
          id="btn-back-to-tickets"
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Tickets</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Quick Actions based on Role */}
          <button
            id="btn-quick-change-status"
            type="button"
            onClick={() => {
              setTargetStatus(allowedTransitions[0] || 'In Progress');
              setStatusModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
          >
            <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
            <span>Update Status</span>
          </button>

          <button
            id="btn-quick-change-priority"
            type="button"
            onClick={() => setPriorityModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            <span>Change Priority</span>
          </button>

          {(activeRole === 'Admin' || activeRole === 'Support Manager') && (
            <button
              id="btn-quick-reassign"
              type="button"
              onClick={() => setReassignModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
            >
              <UserCheck className="w-3.5 h-3.5 text-indigo-600" />
              <span>Reassign Agent</span>
            </button>
          )}
        </div>
      </div>

      {/* Record Banner Card */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <span className="font-mono text-sm font-bold bg-blue-50 text-blue-700 px-2.5 py-0.5 rounded border border-blue-200">
                {ticket.id}
              </span>
              <PriorityBadge priority={ticket.priority} size="md" />
              <StatusBadge status={ticket.status} />
              <SlaBadge sla={sla} />
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">{ticket.subject}</h1>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-500 border-t lg:border-t-0 pt-3 lg:pt-0">
            <div>
              <span className="font-semibold text-slate-700 block">Customer</span>
              <button
                type="button"
                onClick={() => onNavigateToCustomer(ticket.customerId)}
                className="text-blue-600 hover:underline font-medium text-left"
              >
                {ticket.customerName}
              </button>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <div>
              <span className="font-semibold text-slate-700 block">Case Owner</span>
              {ticket.assignedAgentName ? (
                <button
                  type="button"
                  onClick={() => ticket.assignedAgentId && onNavigateToAgent(ticket.assignedAgentId)}
                  className="text-slate-900 hover:text-blue-600 font-medium text-left"
                >
                  {ticket.assignedAgentName}
                </button>
              ) : (
                <span className="text-amber-600 font-medium">Unassigned</span>
              )}
            </div>
          </div>
        </div>

        {/* Salesforce Support Path (Interactive Chevron Workflow) */}
        <div className="pt-2">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Salesforce Support Process Path (Lifecycle Workflow)
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-1 bg-slate-50 p-1.5 rounded-lg border border-slate-200 text-xs font-semibold">
            {lifecycleSteps.map((step, idx) => {
              const isCurrent = step === ticket.status;
              const isPast = idx < currentStepIndex;
              const isNext = allowedTransitions.includes(step);

              return (
                <button
                  key={step}
                  type="button"
                  onClick={() => {
                    if (isNext) {
                      setTargetStatus(step);
                      setStatusModalOpen(true);
                    }
                  }}
                  disabled={!isNext && !isCurrent}
                  className={`py-2 px-2 rounded-md text-center transition-all truncate flex items-center justify-center gap-1 ${
                    isCurrent
                      ? 'bg-blue-600 text-white shadow-xs'
                      : isPast
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : isNext
                      ? 'bg-white text-slate-800 border border-blue-300 hover:bg-blue-50 cursor-pointer ring-1 ring-blue-400/20'
                      : 'text-slate-400 opacity-60 cursor-not-allowed'
                  }`}
                  title={isNext ? `Click to advance status to "${step}"` : step}
                >
                  {isPast && <Check className="w-3 h-3 text-emerald-600 shrink-0" />}
                  <span>{step}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="border-b border-slate-200 bg-white rounded-t-xl px-4 flex gap-6 text-sm font-semibold text-slate-600 shadow-xs">
        <button
          id="tab-btn-details"
          type="button"
          onClick={() => setActiveTab('details')}
          className={`py-3.5 border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'details' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Case Details</span>
        </button>

        <button
          id="tab-btn-comments"
          type="button"
          onClick={() => setActiveTab('comments')}
          className={`py-3.5 border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'comments' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Comments & Feed ({comments.length})</span>
        </button>

        <button
          id="tab-btn-history"
          type="button"
          onClick={() => setActiveTab('history')}
          className={`py-3.5 border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'history' ? 'border-blue-600 text-blue-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Audit History ({history.length})</span>
        </button>

        <button
          id="tab-btn-ai"
          type="button"
          onClick={() => {
            setActiveTab('ai');
            if (!aiResult && !aiLoading) {
              handleRunAiAnalysis();
            }
          }}
          className={`py-3.5 border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'ai' ? 'border-purple-600 text-purple-600' : 'border-transparent hover:text-purple-600'
          }`}
        >
          <Sparkles className="w-4 h-4 text-purple-600" />
          <span>AI Ticket Assistant</span>
          <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded font-bold">
            Gemini
          </span>
        </button>
      </div>

      {/* Tab Content 1: Details */}
      {activeTab === 'details' && (
        <div className="bg-white p-6 rounded-b-xl border border-t-0 border-slate-200 shadow-xs space-y-6">
          {/* Description Block */}
          <div>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Description</h3>
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">
              {ticket.description}
            </div>
          </div>

          {/* Resolution Notes Block (if resolved or closed) */}
          {(ticket.resolutionNotes || ticket.status === 'Resolved' || ticket.status === 'Closed') && (
            <div>
              <h3 className="text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                Resolution Summary Notes
              </h3>
              <div className="p-4 bg-emerald-50/50 rounded-lg border border-emerald-200 text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">
                {ticket.resolutionNotes || 'No notes provided yet.'}
              </div>
            </div>
          )}

          {/* Field Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 border-t border-slate-100 text-sm">
            <div className="space-y-4">
              <div>
                <span className="text-xs font-semibold text-slate-500 block">Category</span>
                <span className="font-medium text-slate-900">{ticket.category}</span>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 block">Customer Email</span>
                <span className="text-slate-800 font-mono text-xs">{ticket.customerEmail}</span>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 block">Assigned Support Agent</span>
                <span className="font-medium text-slate-900">
                  {ticket.assignedAgentName ? `${ticket.assignedAgentName} (${ticket.assignedAgentId})` : 'Waiting for Assignment'}
                </span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <span className="text-xs font-semibold text-slate-500 block">Created Timestamp</span>
                <span className="text-slate-800 text-xs font-mono">{new Date(ticket.createdDate).toLocaleString()}</span>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 block">SLA Target Due Date</span>
                <span className="text-slate-800 text-xs font-mono font-medium flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                  {new Date(ticket.dueDate).toLocaleString()}
                </span>
              </div>
              {ticket.resolutionDate && (
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">Resolution Timestamp</span>
                  <span className="text-emerald-700 text-xs font-mono font-medium">
                    {new Date(ticket.resolutionDate).toLocaleString()}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab Content 2: Comments */}
      {activeTab === 'comments' && (
        <div className="bg-white p-6 rounded-b-xl border border-t-0 border-slate-200 shadow-xs space-y-6">
          {/* New Comment Input Box */}
          <form onSubmit={handleCommentSubmit} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Post Public Comment or Internal Note
              </span>
              <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isInternalNote}
                  onChange={(e) => setIsInternalNote(e.target.checked)}
                  className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                />
                <span className="flex items-center gap-1 font-medium text-amber-800">
                  <Lock className="w-3 h-3 text-amber-600" />
                  Internal Note (Hidden from Customer)
                </span>
              </label>
            </div>

            <textarea
              id="comment-input"
              rows={3}
              value={newCommentText}
              onChange={(e) => setNewCommentText(e.target.value)}
              placeholder={isInternalNote ? 'Log private troubleshooting notes, reproduction steps, or agent handoff...' : 'Type customer response...'}
              className="w-full p-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />

            {commentError && <p className="text-xs text-rose-600 font-medium">{commentError}</p>}

            <div className="flex justify-end">
              <button
                id="btn-post-comment"
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Post Comment</span>
              </button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-4">
            {comments.length === 0 ? (
              <p className="text-sm text-slate-500 py-6 text-center">No comments logged on this ticket yet.</p>
            ) : (
              comments.map((c) => (
                <div
                  key={c.id}
                  className={`p-4 rounded-xl border transition-all ${
                    c.isInternal ? 'bg-amber-50/40 border-amber-200' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900">{c.author}</span>
                      {c.isInternal && (
                        <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.2 rounded border border-amber-300 flex items-center gap-1">
                          <Lock className="w-2.5 h-2.5" />
                          INTERNAL NOTE
                        </span>
                      )}
                    </div>
                    <span className="text-slate-400 font-mono">{new Date(c.createdDate).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">{c.comment}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab Content 3: Audit History */}
      {activeTab === 'history' && (
        <div className="bg-white p-6 rounded-b-xl border border-t-0 border-slate-200 shadow-xs space-y-4">
          <p className="text-xs text-slate-500 mb-2">
            Field Audit History (Salesforce Case History Tracking): Automatically captures changes to Status, Priority, and Assigned Agent.
          </p>
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {history.length === 0 ? (
              <p className="text-sm text-slate-500 p-6 text-center">No history events recorded yet.</p>
            ) : (
              history.map((h) => (
                <div key={h.id} className="p-4 flex items-center justify-between text-xs hover:bg-slate-50/50">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900">{h.fieldChanged}</span>
                      <span className="text-slate-400">changed from</span>
                      <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">{h.oldValue}</span>
                      <span className="text-slate-400">to</span>
                      <span className="font-mono bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-semibold">
                        {h.newValue}
                      </span>
                    </div>
                    <p className="text-slate-500 text-[11px]">Changed by: {h.changedBy}</p>
                  </div>
                  <span className="text-slate-400 font-mono text-[11px]">{new Date(h.timestamp).toLocaleString()}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab Content 4: AI Ticket Assistant */}
      {activeTab === 'ai' && (
        <div className="bg-white p-6 rounded-b-xl border border-t-0 border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-purple-50/70 border border-purple-200 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-purple-600 text-white shadow-xs">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-purple-950">ServiceDesk AI Ticket Assistant</h3>
                <p className="text-xs text-purple-700">
                  Powered by Gemini 3.8 Flash. Analyzes tickets, classifies severity, and drafts suggested customer replies.
                </p>
              </div>
            </div>
            <button
              id="btn-trigger-ai-refresh"
              type="button"
              onClick={handleRunAiAnalysis}
              disabled={aiLoading}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 rounded-lg transition-colors shadow-xs shrink-0"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${aiLoading ? 'animate-spin' : ''}`} />
              <span>{aiLoading ? 'Analyzing...' : 'Re-Analyze Ticket'}</span>
            </button>
          </div>

          {aiLoading && (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Sparkles className="w-8 h-8 text-purple-500 animate-spin mx-auto" />
              <p className="text-sm font-semibold text-slate-700">Evaluating ticket contents with Gemini AI...</p>
              <p className="text-xs text-slate-400">Extracting root cause, classifying priority SLA, and formulating response draft.</p>
            </div>
          )}

          {aiError && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{aiError}</span>
            </div>
          )}

          {aiResult && !aiLoading && (
            <div className="space-y-5">
              {/* Notice pill */}
              <div className="text-[11px] text-slate-500 italic bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                ✨ <strong>AI Suggestion Notice:</strong> All AI outputs are recommendations for support agents. Do not make irreversible decisions without review.
              </div>

              {/* Summary & Core Root Cause */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Issue Summary</span>
                  <p className="text-sm text-slate-900 leading-relaxed">{aiResult.issueSummary}</p>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-1.5">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Key Root Cause</span>
                  <p className="text-sm text-slate-900 leading-relaxed">{aiResult.keyIssue}</p>
                </div>
              </div>

              {/* Recommendations Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Suggested Category</span>
                    <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      {aiResult.suggestedCategory}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">Current category is "{ticket.category}".</p>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Suggested Priority</span>
                    <PriorityBadge priority={aiResult.suggestedPriority} />
                  </div>
                  <p className="text-xs text-slate-600">{aiResult.priorityRationale}</p>
                  {aiResult.suggestedPriority !== ticket.priority && (
                    <button
                      type="button"
                      onClick={() => onUpdatePriority(ticket.id, aiResult.suggestedPriority)}
                      className="text-xs font-semibold text-blue-600 hover:underline pt-1 block"
                    >
                      Apply Suggested Priority ({aiResult.suggestedPriority})
                    </button>
                  )}
                </div>
              </div>

              {/* Drafted Customer Response */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Drafted Professional Customer Response
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(aiResult.suggestedResponse);
                        setCopiedDraft(true);
                        setTimeout(() => setCopiedDraft(false), 2000);
                      }}
                      className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 border border-slate-200 px-2.5 py-1 rounded-md bg-slate-50"
                    >
                      {copiedDraft ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedDraft ? 'Copied' : 'Copy'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setNewCommentText(aiResult.suggestedResponse);
                        setActiveTab('comments');
                      }}
                      className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-semibold border border-blue-200 px-2.5 py-1 rounded-md bg-blue-50"
                    >
                      <span>Insert into Comments</span>
                    </button>
                  </div>
                </div>
                <div className="p-3.5 bg-slate-50 rounded-lg text-sm text-slate-800 leading-relaxed whitespace-pre-wrap border border-slate-200">
                  {aiResult.suggestedResponse}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* --- Modals --- */}

      {/* Status Transition Modal */}
      <Modal
        isOpen={statusModalOpen}
        onClose={() => setStatusModalOpen(false)}
        title="Update Case Status"
        subtitle="Enforce Salesforce Support Process transitions and resolution rules"
        maxWidth="md"
      >
        <form onSubmit={handleStatusSubmit} className="space-y-4">
          {statusError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs font-medium text-rose-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{statusError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              New Status
            </label>
            <select
              id="select-target-status"
              value={targetStatus}
              onChange={(e) => setTargetStatus(e.target.value as TicketStatus)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              {allowedTransitions.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {(targetStatus === 'Resolved' || targetStatus === 'Closed') && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Resolution Notes <span className="text-rose-500">* (Mandatory validation rule)</span>
              </label>
              <textarea
                id="textarea-resolution-notes"
                rows={3}
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
                placeholder="Explain the technical resolution steps and customer signoff..."
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setStatusModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              id="btn-confirm-status"
              type="submit"
              className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Confirm Transition
            </button>
          </div>
        </form>
      </Modal>

      {/* Priority Modal */}
      <Modal
        isOpen={priorityModalOpen}
        onClose={() => setPriorityModalOpen(false)}
        title="Change Ticket Priority"
        subtitle="Modifies SLA target resolution countdown"
        maxWidth="sm"
      >
        <form onSubmit={handlePrioritySubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Select Priority
            </label>
            <select
              id="select-target-priority"
              value={targetPriority}
              onChange={(e) => setTargetPriority(e.target.value as TicketPriority)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="Critical">Critical (4h SLA)</option>
              <option value="High">High (8h SLA)</option>
              <option value="Medium">Medium (24h SLA)</option>
              <option value="Low">Low (48h SLA)</option>
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setPriorityModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              id="btn-confirm-priority"
              type="submit"
              className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Update Priority
            </button>
          </div>
        </form>
      </Modal>

      {/* Reassign Modal */}
      <Modal
        isOpen={reassignModalOpen}
        onClose={() => setReassignModalOpen(false)}
        title="Reassign Support Agent"
        subtitle="Salesforce Case Assignment / Transfer Case"
        maxWidth="md"
      >
        <form onSubmit={handleReassignSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Target Agent
            </label>
            <select
              id="select-target-agent"
              value={targetAgentId}
              onChange={(e) => setTargetAgentId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="">Unassigned (Queue)</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.fullName} - {a.department} ({a.availability}, {a.activeTickets} active tickets)
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setReassignModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              id="btn-confirm-reassign"
              type="submit"
              className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              Transfer Case
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
