import React, { useState } from 'react';
import { Customer, Agent, TicketCategory, TicketPriority } from '../../types';
import { Modal } from '../common/Modal';
import { SLA_HOURS_MAP } from '../../services/automationService';
import { Sparkles, Zap, AlertCircle, Clock } from 'lucide-react';

interface TicketCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  customers: Customer[];
  agents: Agent[];
  categories: TicketCategory[];
  onSubmit: (payload: {
    subject: string;
    description: string;
    customerId: string;
    category: string;
    priority: TicketPriority;
    assignedAgentId?: string | null;
  }) => { success: boolean; error?: string; assignmentNote?: string };
}

export function TicketCreateModal({
  isOpen,
  onClose,
  customers,
  agents,
  categories,
  onSubmit,
}: TicketCreateModalProps) {
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [customerId, setCustomerId] = useState(customers[0]?.id || '');
  const [category, setCategory] = useState(categories[0]?.name || 'Technical Issue');
  const [priority, setPriority] = useState<TicketPriority>('Medium');
  const [assignedAgentId, setAssignedAgentId] = useState<string>(''); // empty string = auto-assign rule
  const [validationError, setValidationError] = useState<string | null>(null);

  const activeCustomers = customers.filter((c) => c.status === 'Active');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    // Form Validation (Validation Rules)
    if (!subject.trim()) {
      setValidationError('Validation Rule: Ticket Subject cannot be empty.');
      return;
    }
    if (!description.trim()) {
      setValidationError('Validation Rule: Ticket Description cannot be empty.');
      return;
    }
    if (!customerId) {
      setValidationError('Validation Rule: Please select a valid Customer.');
      return;
    }
    if (!category) {
      setValidationError('Validation Rule: Please select a Category.');
      return;
    }
    if (!priority) {
      setValidationError('Validation Rule: Please select a Priority.');
      return;
    }

    const res = onSubmit({
      subject,
      description,
      customerId,
      category,
      priority,
      assignedAgentId: assignedAgentId ? assignedAgentId : null,
    });

    if (res.success) {
      // Reset form
      setSubject('');
      setDescription('');
      setAssignedAgentId('');
      onClose();
    } else {
      setValidationError(res.error || 'Failed to create ticket.');
    }
  };

  const slaHours = SLA_HOURS_MAP[priority];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create New Support Ticket"
      subtitle="Salesforce Case Creation with Automated Assignment & SLA Calculation"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {validationError && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2.5 text-rose-800 text-xs font-medium">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Customer & Category Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Customer (Account) <span className="text-rose-500">*</span>
            </label>
            <select
              id="field-customer"
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            >
              <option value="">-- Select Customer --</option>
              {activeCustomers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} ({c.company})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500 mt-1">Lookup relationship to Customer Object</p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Category <span className="text-rose-500">*</span>
            </label>
            <select
              id="field-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            >
              {categories.map((cat) => (
                <option key={cat.id} value={cat.name}>
                  {cat.name}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500 mt-1">Used by Case Assignment Rules to match agent skill</p>
          </div>
        </div>

        {/* Subject */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Subject <span className="text-rose-500">*</span>
          </label>
          <input
            id="field-subject"
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Brief summary of the issue or inquiry"
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Description <span className="text-rose-500">*</span>
          </label>
          <textarea
            id="field-description"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Detailed description of the problem, error logs, and customer impact..."
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        {/* Priority & Assignment Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Priority <span className="text-rose-500">*</span>
            </label>
            <select
              id="field-priority"
              value={priority}
              onChange={(e) => setPriority(e.target.value as TicketPriority)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            >
              <option value="Critical">Critical (4h SLA)</option>
              <option value="High">High (8h SLA)</option>
              <option value="Medium">Medium (24h SLA)</option>
              <option value="Low">Low (48h SLA)</option>
            </select>
            <div className="flex items-center gap-1 text-[11px] text-amber-700 mt-1 font-medium">
              <Clock className="w-3 h-3" />
              <span>Target resolution deadline: {slaHours} hours SLA</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Assigned Agent (Case Owner)
            </label>
            <select
              id="field-agent"
              value={assignedAgentId}
              onChange={(e) => setAssignedAgentId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            >
              <option value="">⚡ Auto-Assign (Omni-Channel Flow)</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.fullName} - {a.department} ({a.availability})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500" />
              <span>Auto-assign evaluates certified skill and lowest workload</span>
            </p>
          </div>
        </div>

        {/* Modal Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            id="btn-submit-create-ticket"
            type="submit"
            className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
          >
            Create Ticket
          </button>
        </div>
      </form>
    </Modal>
  );
}
