import React, { useState, useMemo } from 'react';
import { Ticket, Agent, Customer, TicketCategory, TicketPriority, TicketStatus } from '../../types';
import { StatusBadge, PriorityBadge, SlaBadge } from '../common/Badges';
import { calculateSlaStatus } from '../../services/automationService';
import {
  Search,
  Filter,
  ArrowUpDown,
  Plus,
  AlertOctagon,
  Clock,
  Eye,
  CheckCircle,
  FileSpreadsheet,
} from 'lucide-react';

interface TicketListProps {
  tickets: Ticket[];
  agents: Agent[];
  customers: Customer[];
  categories: TicketCategory[];
  onSelectTicket: (ticketId: string) => void;
  onOpenCreateModal: () => void;
  initialFilters?: {
    status?: string;
    priority?: string;
    overdueOnly?: boolean;
    search?: string;
  };
}

export function TicketList({
  tickets,
  agents,
  categories,
  onSelectTicket,
  onOpenCreateModal,
  initialFilters,
}: TicketListProps) {
  const [searchTerm, setSearchTerm] = useState(initialFilters?.search || '');
  const [selectedStatus, setSelectedStatus] = useState<string>(initialFilters?.status || 'All');
  const [selectedPriority, setSelectedPriority] = useState<string>(initialFilters?.priority || 'All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedAgent, setSelectedAgent] = useState<string>('All');
  const [overdueOnly, setOverdueOnly] = useState<boolean>(initialFilters?.overdueOnly || false);
  const [sortBy, setSortBy] = useState<'created_desc' | 'created_asc' | 'priority' | 'due_date'>('created_desc');

  // Filtered & Sorted Tickets
  const filteredTickets = useMemo(() => {
    return tickets
      .filter((t) => {
        // Search
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          const match =
            t.id.toLowerCase().includes(q) ||
            t.subject.toLowerCase().includes(q) ||
            t.customerName.toLowerCase().includes(q) ||
            (t.assignedAgentName && t.assignedAgentName.toLowerCase().includes(q)) ||
            t.category.toLowerCase().includes(q) ||
            t.status.toLowerCase().includes(q) ||
            t.priority.toLowerCase().includes(q);
          if (!match) return false;
        }

        // Status Filter
        if (selectedStatus !== 'All' && t.status !== selectedStatus) {
          return false;
        }

        // Priority Filter
        if (selectedPriority !== 'All' && t.priority !== selectedPriority) {
          return false;
        }

        // Category Filter
        if (selectedCategory !== 'All' && t.category !== selectedCategory) {
          return false;
        }

        // Agent Filter
        if (selectedAgent !== 'All') {
          if (selectedAgent === 'Unassigned') {
            if (t.assignedAgentId !== null) return false;
          } else if (t.assignedAgentId !== selectedAgent) {
            return false;
          }
        }

        // Overdue Only
        if (overdueOnly) {
          const sla = calculateSlaStatus(t);
          if (sla.state !== 'Overdue') return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'priority') {
          const pOrder: Record<TicketPriority, number> = { Critical: 4, High: 3, Medium: 2, Low: 1 };
          return pOrder[b.priority] - pOrder[a.priority];
        }
        if (sortBy === 'due_date') {
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        }
        if (sortBy === 'created_asc') {
          return new Date(a.createdDate).getTime() - new Date(b.createdDate).getTime();
        }
        // Default: created_desc
        return new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime();
      });
  }, [tickets, searchTerm, selectedStatus, selectedPriority, selectedCategory, selectedAgent, overdueOnly, sortBy]);

  // Quick stats on current view
  const currentViewStats = useMemo(() => {
    const total = filteredTickets.length;
    const critical = filteredTickets.filter((t) => t.priority === 'Critical').length;
    const overdue = filteredTickets.filter((t) => calculateSlaStatus(t).state === 'Overdue').length;
    return { total, critical, overdue };
  }, [filteredTickets]);

  const exportCSV = () => {
    const headers = ['Ticket ID', 'Subject', 'Customer', 'Agent', 'Category', 'Priority', 'Status', 'Due Date', 'Created Date'];
    const rows = filteredTickets.map((t) => [
      t.id,
      `"${t.subject.replace(/"/g, '""')}"`,
      `"${t.customerName.replace(/"/g, '""')}"`,
      `"${(t.assignedAgentName || 'Unassigned').replace(/"/g, '""')}"`,
      t.category,
      t.priority,
      t.status,
      t.dueDate,
      t.createdDate,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ServiceDesk_Tickets_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="tickets-view" className="space-y-5 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Support Tickets (Cases)</h1>
            <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full border border-slate-200">
              {filteredTickets.length} of {tickets.length} Records
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Manage customer support cases, monitor SLA countdowns, and execute lifecycle status workflows.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-export-tickets-csv"
            type="button"
            onClick={exportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>

          <button
            id="btn-create-ticket-view"
            type="button"
            onClick={onOpenCreateModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>New Ticket</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        {/* Row 1: Search & Sort */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="filter-ticket-search"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by ticket ID, subject, customer, agent, category..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              id="filter-ticket-sort"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            >
              <option value="created_desc">Created: Newest First</option>
              <option value="created_asc">Created: Oldest First</option>
              <option value="priority">Priority: Critical First</option>
              <option value="due_date">Due Date: Soonest First</option>
            </select>
          </div>
        </div>

        {/* Row 2: Status, Priority, Category, Agent, Overdue Switch */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1 text-xs">
          {/* Status Filter */}
          <div>
            <label className="block font-semibold text-slate-500 mb-1">Status</label>
            <select
              id="filter-status"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="All">All Statuses</option>
              <option value="New">New</option>
              <option value="Open">Open</option>
              <option value="In Progress">In Progress</option>
              <option value="Waiting for Customer">Waiting for Customer</option>
              <option value="Resolved">Resolved</option>
              <option value="Closed">Closed</option>
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <label className="block font-semibold text-slate-500 mb-1">Priority</label>
            <select
              id="filter-priority"
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="All">All Priorities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block font-semibold text-slate-500 mb-1">Category</label>
            <select
              id="filter-category"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="All">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Agent Filter */}
          <div>
            <label className="block font-semibold text-slate-500 mb-1">Agent (Owner)</label>
            <select
              id="filter-agent"
              value={selectedAgent}
              onChange={(e) => setSelectedAgent(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option value="All">All Agents</option>
              <option value="Unassigned">Unassigned Only</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.fullName}
                </option>
              ))}
            </select>
          </div>

          {/* Overdue Only Toggle */}
          <div className="flex flex-col justify-end">
            <button
              id="filter-overdue-toggle"
              type="button"
              onClick={() => setOverdueOnly(!overdueOnly)}
              className={`w-full px-2.5 py-1.5 rounded-md border font-medium flex items-center justify-center gap-1.5 transition-colors ${
                overdueOnly
                  ? 'bg-red-50 border-red-300 text-red-700 font-bold'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Overdue Only</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tickets Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <th className="py-3 px-4">Ticket ID</th>
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Assigned Agent</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">SLA State</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800 font-normal">
              {filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    <AlertOctagon className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="text-sm font-medium">No tickets match your filter criteria.</p>
                    <p className="text-xs text-slate-400 mt-1">Try resetting search or adjusting filters.</p>
                  </td>
                </tr>
              ) : (
                filteredTickets.map((ticket) => {
                  const sla = calculateSlaStatus(ticket);
                  return (
                    <tr
                      key={ticket.id}
                      id={`ticket-row-${ticket.id}`}
                      onClick={() => onSelectTicket(ticket.id)}
                      className="hover:bg-blue-50/40 cursor-pointer transition-colors group"
                    >
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-600 whitespace-nowrap">
                        {ticket.id}
                      </td>
                      <td className="py-3.5 px-4 max-w-xs truncate font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                        {ticket.subject}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap text-slate-700">
                        {ticket.customerName}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {ticket.assignedAgentName ? (
                          <span className="text-slate-800 font-medium">{ticket.assignedAgentName}</span>
                        ) : (
                          <span className="text-amber-600 font-medium bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            Waiting for Assignment
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap text-slate-600">
                        {ticket.category}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <PriorityBadge priority={ticket.priority} />
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <StatusBadge status={ticket.status} />
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <SlaBadge sla={sla} />
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectTicket(ticket.id);
                          }}
                          className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-100 rounded-md transition-colors"
                          title="Open Ticket Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
